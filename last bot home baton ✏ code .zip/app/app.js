/* V9 FULL RESTORED - ADMIN ONLY + DEVELOPER PIC + NO DEBUG + ALL FEATURES RESTORED - FIXED INSTANT UPDATE */
const tg = window.Telegram?.WebApp || null;
if (tg) { tg.ready(); tg.expand(); tg.setHeaderColor?.('#071426'); tg.setBackgroundColor?.('#071426'); }
const userId = tg?.initDataUnsafe?.user?.id || null;
let BOT_API = new URL('./bot.php', window.location.href).href;
if (location.pathname.includes('/app/')) { BOT_API = new URL('../bot.php', window.location.href).href; } 
else { const path = window.location.pathname; if (path.includes('.php')) { BOT_API = window.location.origin + path; } }

const ADMIN_UID = 6560485203;
const DEV_PIC = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5Ojf/2wBDAQoKCg0MDRoPDxo3JR8lNzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzf/wAARCACAAIADASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAABQYDBAcBAgAI/8QAMxAAAgEDAgQFAQgCAwEAAAAAAQIDAAQRBSEGEjFBEyJRYXGBBxQyQpGhscEjYiRSctH/xAAaAQACAwEBAAAAAAAAAAAAAAADBAECBQYA/8QAJhEAAgIBBAEEAwEBAAAAAAAAAQIAAxEEEiExQQUiUXETIzIUYf/aAAwDAQACEQMRAD8AUdPawiZWaEkjvzHerko06bJ5WQk560KgSMvhZM1chWJurjNI5PkTYAQnIMtW8FokissjE+lT3NtDkytLjAzio7O3aadI4V53Y4VR1NNlnwxFkT6oQ4HSFen19f4qPuQxweDMo1m+mMUa2/MyyJz+VSQN+lAPEPMARhu5Ir9E3EMkUZMMNokCpgCQkfwOlYTxFODqtxLi353ck+CuFG+KZpYdARG8HOSZSaWWROXqB+1QMx2ztjv2r0Ji68p23yx9q7JF4hXcDI2HYCj/AFFc/MhkmZts7V0SkgKc+lRyKqthST71NBazSKWRSQu+1RJE0rRLVobCFMvjkB396meC5Zjyc1V+Hb173SYZMFnXyPj1FEAJuccoYUg2QcGbSAFcgyq0d4qkMGqu4vOg5sUTumuQQBzYx6VAj3JByDj4qMycHGeIPvBcrEoCknvQ5jcg9GH0q7cXtwsjLg7H0qMXczTKCu3xXpA4Eit7SOJsq+aswWalubxAPaq8MT9e1WFt2O9XLZlFQA8GN3BNqqXssrBXcJhCfy+tMupXE0CYtITPcNsMnCp7k0vcIwtFBznqz/tVnjLXk0LS5LhFEkuMKpPc1Tsyj8HmJPGFtqsQll1PiCJFxlbaDJ/UnFZ5LMMkpvnq7bk1a1G9u9Sma61GcszdB/QFQ+GjQKDgMtPIu0TOsfc3Epkkk+9TpJ/jAySc461EU8wXIJNfRnD49dqtKTrZklxjqcbCtN4Z0FDYLlT5vMQe9DOGOAbu8aG5uWQRsA2O9ajBpS6fbLyNzcowT6CgWWDoQ6VN2Ynto0mjyyTWbf4ZsF48fhb1FeGurpG82f0ph0ZLvVr4aj4qjTo3YRwlB/kA2DE/IP0olr1na31hNcWTI80S82xyduopdycx+ggL1EttQuM9M/Solv7kty8uB8V1ZZA26ftXm8mlSLnjQZqinJhnAAziVZ7qRXIMYP0qJrxwRmMfpUYu5m3aPer0coeHLxjmq5yJQEEDiUYJcsMjarkl5BCYo5XCvK3LGvdjQy3S5zulSaK1tqHGNkl23ILeQnzYwSoyAPr/ABRRX3mLNqRxjualo9r91tIkk2KrvWc/azeeI9rAh2Lk4zttWgarqKQQsz5VVBJYdhWRcQ3kGveLdRJIRFKI4m/7DBJ2/SqUjLSLmwpz5i94WxblZ8dNtqryc6ncEVNKZYHKMWX02ry3isvKwPMfbc07mIYlcE5z3o3wnocut6mkS8yxIcyOB0Hp81X0vRbu8u44/Ak5Cdzy0+XVynDOlG10dFjuHGZJW6r7/NBssA9o7h66s+5uo/2NzZWHh2SPzzIoURRDJUe/pXOILqWezSwssrc3riBCPyA/ib6Ln64rI7biVrTwIo7vlhlPNcFAWlJ9ydjn26VovAU0Or38+pox8O3QW8CSHzAHdmI7EnH0FCZNvMOtgbiNVpZQafHFbxLi3CiML6AdK5JCscd2yphY42WNRjLbb/vtVu9CkYFUXkcsULnlIzy+9BJh14mSXPFFpAxR0kYrscLjB9N6+h4l0+5UczmH1Eg/umTizgu21lpJrfFveDcOBs//AKH91nN/w5eadL4NzNCj/l58qG+DjFN1pVYOO/uKW2X1nJPH1G4yQzRh4GR1P5lORXefC4I2oNw3Dc2cE0VxGVAYFd8hgR1BHWikl9GVKkDaq3UMhHwZfS6tLQR5HcNwWme1CNR4JOoNNc6dMIZ+Ykq+eVj3we1NKsscWQN+3zV+zHhQY/WqNYydGDqqD53TJ7/ReJ0T7td3D+CTy4NxzKfpTxo3DVpZ6TFZSr4pVudnIxlj3r3qzCS/tg5AUzLnPzRSTVtNhVi95B5eoDAn9Ksjs46lblWs9xPsuBpW1aaa+lRrfJKBerZ6fGKK6xZ6Nodi0/3eKS5TBRMjmbfFR3PGvJKwtLZGjHRnOCfekXW724lUu7szSPzs3pTYpJUl+oj/AKRuAr7hmTi7ULPxTDY2cSLJgpzgkE/z8iq2v6zLrOlxzRWMqIGxc3AGVLdl9h33pUGHYiQ5J71o/wBjEwOo6hYTKGt5YlZgwyMg4/v9qWatU5Aj6WPZ7Se5nipGuHBzWh/ZLHdPq808Qb7sIikjHoTkYHz1pw1XhnhOG5ZTpkRnk3yCVRffHT9qIxXOn6PHBBDEscbbKFAUZ9hVHsyMCFSracmGZFPKMmhNxKFvYwD65q492sqgoeopfuLnm1BsHZdqWJjIHMNOgbDChus6bb31o8VxErqezDNWobkcnmNC9a1QRW0nIfMRgfNQoLMAOzPWMEUs3QiZb2kNkHggz4Yc4yc1E1vH4nM42PXFWl6b1G7DmI9MCup/EpQIZwI1VguNq8ExlhUvJGp9aLSeVMUKt5V++BAQWRQWHpnp/FEpZWKFc5rmre529H8RT4vV3tnVQebG2KzuOSSN8PkZOM1o/F1y0Wnu3MAxOF26mkeKSd2ALYCqMAAU5og204iOvZQwBnYyzDrmpguRhhkGvSRq2STv3NfMxj7gj3rTAxMUtk8ShPYwEtgFD7HamHgzWRpEJSaBWidjmRBhv17j2oOIL3UG8KxtHmY7ZUbD61bjsptPiNtdKBNHs4Bzg0E112EqY0LraVDg+Y9aZdGbEkC+PM2T4ryZVM+lELdozcLGrG5vOsj4yE9h6Cs3s2mgJmhkaNs9j1+aZtK4jkEkNuLVRNK6pzIcDJPXFJWaN1/jmadHqtTLtcYMdbmZLW2d5GHPjGOm9LTXi8w9Seuepqfi60eGztrrMkoiuAZT/qRjOPSqTw2s0WYnUkjKkGk9RS1R2tHtPcty7llg6iwXlFCL2dpJArHpuaO6foskxEs5MUQGSSNyPal+7dZbqWSNAsZbyD0HanfT9K+8WMMAdTJ9Z1qLUaUOSe5GHOKHC4BJZs5ZyVA6kdKs3k3gQSSN0RScCqFkrFPFk/G3T29q2mPOJzdSDaWMa0lig1yfxJFTx4FZOY4yVJB/mp7jW7S1UmSZWPopyakeOG4XlmiRx/sM1m/Ecz2Gs3ECRKIgQUG/QisIVpY3uM6v81tS4QAwlrOpSarc8z+SJPwJ/dD42AZzjAG2aGS6oWQAQgeu9QXV/NcALsiD8q96dVkRcLM9q7bW3P5hS51CGLYks3otC5dQlc+Qco996qVyqNYxh0oRI66L9oNxYRJBPZQtEu3+Ichqxc3qalcS3qKVSZuYKeoFIVOOnbabD/4FX0yjcTF9ef1gf9lhVzFnoM0Z4UtFuNVjlI2icY+aDplkjRSMtsBTzpFkumvAVGQFAY+p9afUZmYnfMbCgIOQCO4NRi2srXLx20UbeqoBUviqEDdQRUUYMr88nQdBUlQTyIcMQMAwHxfqh0/SWIB8W4PIiD8RHc/p/NJNvdwXAxE/mHVG2I+lN/HcEUtqtyXAeDygHoeY9Pms01yIQQowOHLDcdc5qGYrzANUtrhTwfEv603/ABgn/eRV/fP9Vw4UKo6Ch8RluEiM8hZVbKg1cmbzDHaqA5JM9s2AJ9xvhZupO1K32gWSSWsF8oxIrcjH1HamWGTJAAoLxxKo0MqQcmQYx2rFX+hOkPUzkH1r7NeiM+Zf0rx0piDna4aYJuEr8WEV5bFZ1dAxRdmH/wBoA6NG5SRSrDqCMEVUEHqTjE804WQLafAg7oMmk+nCylSPSI5sjaMdaZ0/ZiOvztXHzKWtXzWxjigOHUhiR2ArWNCuo9S0u3uV3EiAn5rErmV5pGcg5J606fZtrrWsx0y5OY3PNFnse4pim39hB6MFbRtpGOxNQiWVMcp5l7A1aDkLvsfSo4JUkUFT9K+duWTzdO1NkRRTE37QbgiC2ts7yMZGHxsP5NZ9rExl+6xucnO/0pw45nMut4G4SJQP3NImrnF5D7Kf5pW48GFoG6yFI2AKAdBXLtyV5FOGc4z6DuagtG5xk+lV5rom9ZFGyDBPYVUtxJWsl/qaRZ6Ve3GGVDGvq21XrrheK9s5be7YurDt2PrTi6xhcAD6VXmMYiOCAKWWhB3Hm1DGYhr3BV5pcoNtKs8TDKk7H4oGNInRh948n+o3NbtqSWN3CIrnl26YOCDQSHh3T1uRPhpGBypc7Ch2Vtu4PEPXcm33A5lK18e00S2a4XEioM/FDr3TtP1mI/eIgsnaRdiKL8T3Cx2rIrAu2wUUFsiyxAEHNK2e1+Iwh3LkxL1nh+60xi4HiwdpFHT5r60kaayigU5VScitB6pysAVPUEdaX9U4c8zXOkt4UvUx/lai1XgH3QV1O4cQMkK/hYV6t4GF7brFs5lXB+tQtfGNjBfwmGUd8V1r4Wk8M6MH5HDA/WnwyEZBmcUsBwRNjs5D4S87csgH4vWppbiYjqrih1hL4ypcRESW8yhlI7Grknhkcx8prTKjxMtXPmInE8hbWpiRjCqMfSk/WeZ7kFN/DTJ+M01cVMF1qUqcgqpz9KXwQbyV8flC1n3DJxHtOdp3T60kCWXiE9RmqdlH4rtL4nmY5K4r3fuI4SqDGdsCvdnD4MQx+LqTQe2A+Iz0pb5n/9k=";

function isAdminUser(){
  try{
    const tid = tg?.initDataUnsafe?.user?.id || userId || state.user?.id || 0;
    return Number(tid) === Number(ADMIN_UID);
  }catch(e){ return false; }
}
const ADMIN_PASS = "noyon@18";
function openAdminPanel(){
  try{
    const authed = sessionStorage.getItem('admin_auth');
    if(authed !== 'ok'){
      const p = prompt('🔐 Admin Password din:');
      if(p !== ADMIN_PASS){ toast('❌ Wrong password!'); return; }
      sessionStorage.setItem('admin_auth','ok');
    }
  }catch(e){
    const p = prompt('🔐 Admin Password din:');
    if(p !== ADMIN_PASS){ toast('❌ Wrong password!'); return; }
  }
  setTimeout(()=>{ loadAdminBonusTasks(); },500);
  const el = document.getElementById('adminPanel');
  if(el){ el.style.display='grid'; el.classList.remove('hidden'); loadAdminSettings(); }
  if(tg?.HapticFeedback) tg.HapticFeedback.impactOccurred('medium');
}
function closeAdminPanel(){
  const el = document.getElementById('adminPanel');
  if(el){ el.style.display='none'; el.classList.add('hidden'); }
}
window.openAdminPanel = openAdminPanel;
window.closeAdminPanel = closeAdminPanel;

async function loadAdminSettings(){
  try{
    const sPoro = document.getElementById('adminPoroReward');
    const sLijent = document.getElementById('adminLijentReward');
    const sMin = document.getElementById('adminMinWithdraw');
    const sMinUsdt = document.getElementById('adminMinUsdt');
    const sMinRecharge = document.getElementById('adminMinRecharge');
    const sAllowed = document.getElementById('adminAllowedCountries');
    const sPoroLim = document.getElementById('adminPoroLimit');
    const sLijentLim = document.getElementById('adminLijentLimit');
    const sWelcome = document.getElementById('adminWelcomeNotice');
    const sEarning = document.getElementById('adminEarningPopup');
    const sBonus = document.getElementById('adminBonusText');
    const sPayment = document.getElementById('adminPaymentInput');
    const sMonetag = document.getElementById('adminMonetagCode');
    const sAdspark = document.getElementById('adminAdsparkCode');
    if(!sPoro) return;
    const res = await api('admin_get_settings');
    if(res && res.ok && res.settings){
      if(res.settings.poro_reward !== undefined) sPoro.value = res.settings.poro_reward;
      if(res.settings.lijent_reward !== undefined) sLijent.value = res.settings.lijent_reward;
      if(res.settings.min_withdraw !== undefined) sMin.value = res.settings.min_withdraw;
      if(res.settings.min_usdt !== undefined && sMinUsdt) sMinUsdt.value = res.settings.min_usdt;
      if(res.settings.min_recharge !== undefined && sMinRecharge) sMinRecharge.value = res.settings.min_recharge;
      if(res.settings.poro_limit !== undefined && sPoroLim) sPoroLim.value = res.settings.poro_limit;
      if(res.settings.lijent_limit !== undefined && sLijentLim) sLijentLim.value = res.settings.lijent_limit;
      if(res.settings.allowed_countries !== undefined) sAllowed.value = (res.settings.allowed_countries||[]).join(',');
      if(res.settings.welcome_notice !== undefined && sWelcome) sWelcome.value = res.settings.welcome_notice;
      if(res.settings.earning_popup !== undefined && sEarning) sEarning.value = res.settings.earning_popup;
      if(res.settings.bonus_text !== undefined && sBonus) sBonus.value = res.settings.bonus_text;
      if(res.settings.payment_methods !== undefined && sPayment) { sPayment.value = res.settings.payment_methods; updatePaymentPreview(res.settings.payment_methods); }
      if(res.settings.monetag_code !== undefined && sMonetag) sMonetag.value = res.settings.monetag_code;
      if(res.settings.adspark_code !== undefined && sAdspark) sAdspark.value = res.settings.adspark_code;
      if(res.settings.notice_ad_set !== undefined) window._noticeAdSet = Number(res.settings.notice_ad_set || 5);
      if(res.settings.notice_add_second_set !== undefined) window._noticeAddSecondSet = Number(res.settings.notice_add_second_set || 30);
      if(res.settings.home_notice !== undefined) window._homeNotice = String(res.settings.home_notice || '');
      if(res.settings.home_notice_country !== undefined) window._homeNoticeCountry = String(res.settings.home_notice_country || 'Australia');
      if(res.settings.home_notice_text !== undefined) window._homeNoticeText = String(res.settings.home_notice_text || '');
    }
  }catch(e){}
}
async function saveAdminSettings(){
  const adNetPanel = document.getElementById('admContent_adnetwork');
  const btn = (adNetPanel && adNetPanel.style.display !== 'none') ? document.getElementById('adminAdNetworkSaveBtn') : document.getElementById('adminSaveBtn');
  const poro = document.getElementById('adminPoroReward')?.value;
  const lijent = document.getElementById('adminLijentReward')?.value;
  const minW = document.getElementById('adminMinWithdraw')?.value;
  const minUsdt = document.getElementById('adminMinUsdt')?.value;
  const minRecharge = document.getElementById('adminMinRecharge')?.value;
  const allowed = document.getElementById('adminAllowedCountries')?.value;
  const monetagCode = document.getElementById('adminMonetagCode')?.value ?? '';
  const adsparkCode = document.getElementById('adminAdsparkCode')?.value ?? '';
  const settings = {
    poro_reward: Number(poro||0),
    lijent_reward: Number(lijent||0),
    min_withdraw: Number(minW||0),
    min_usdt: Number(minUsdt||0),
    min_recharge: Number(minRecharge||0),
    allowed_countries: String(allowed||'BD').split(',').map(s=>s.trim().toUpperCase()).filter(Boolean),
    monetag_code: String(monetagCode).trim(),
    adspark_code: String(adsparkCode).trim()
  };
  if(btn){ btn.textContent='Saving...'; btn.disabled=true; }
  try{
    const res = await api('admin_save_settings', {settings: JSON.stringify(settings)});
    localStorage.setItem('admin_settings_v1', JSON.stringify(settings));
    state.min_withdraw = settings.min_withdraw;
    state.min_usdt = settings.min_usdt;
    state.min_recharge = settings.min_recharge;
    state.allowed_countries = settings.allowed_countries;
    state.allowed_country_names = settings.allowed_countries.join(', ');
    state.ad_networks = {
      monetag: {enabled: settings.monetag_code !== '', code: settings.monetag_code},
      adspark: {enabled: settings.adspark_code !== '', code: settings.adspark_code}
    };
    cachedCountry = null;
    try{ localStorage.setItem('admin_settings_cache', JSON.stringify(settings)); }catch(e){}
    getUserCountry(true).then(()=>{ updateVpnBadges(); }).catch(()=>{});
    if(res && res.ok){ toast('Admin settings saved ✅'); } else { toast('Saved & Applied ✅'); }
    setTimeout(()=>{ updateVpnBadges(); }, 500);
  }catch(e){ toast('Save failed'); } finally { if(btn){ btn.textContent='Save Settings'; btn.disabled=false; } }
}
window.saveAdminSettings = saveAdminSettings;

const screen = document.getElementById('screen');
const toastEl = document.getElementById('toast');
const telegramUser = tg?.initDataUnsafe?.user || null;
let state = {
 user: telegramUser ? { id: telegramUser.id, name: [telegramUser.first_name, telegramUser.last_name].filter(Boolean).join(' ') || telegramUser.username || 'User', photo_url: telegramUser.photo_url || '', username: telegramUser.username || '', balance: 0 } : null,
 ads: [], top_referrers: [], top_earners: [], ref_link: '', min_withdraw: 100, min_usdt: 1, min_recharge: 20,
 allowed_countries: ['BD'], allowed_country_names: 'Bangladesh',
 earnings_history: []
};
let currentTab='home'; let selectedMethod='';
const PAYMENT_MAP={bk:'bKash',bkas:'bKash',bkash:'bKash',nk:'Nagad',ng:'Nagad',nagad:'Nagad',rk:'Rocket',rocket:'Rocket',bc:'Binance',binance:'Binance',rc:'Mobile Recharge',recharge:'Mobile Recharge','mobile_recharge':'Mobile Recharge','mobile recharge':'Mobile Recharge'};
function paymentMethodLabelClient(method){ const m=String(method||'').trim().toLowerCase(); return PAYMENT_MAP[m] || m || 'Unknown'; }
function parsePaymentMethods(){ try{ var cached=null; try{ cached=localStorage.getItem('payment_methods_cache'); }catch(e){} var raw=cached||(state.settings&&state.settings.payment_methods)||'bk,nk,rk'; var codes=String(raw).split(',').map(function(s){return s.trim();}).filter(Boolean); var res=[]; for(var i=0;i<codes.length;i++){ var c=codes[i]; var low=c.toLowerCase(); res.push(PAYMENT_MAP[low]||c); } return res.length?res:['bKash','Nagad','Rocket']; }catch(e){ return ['bKash','Nagad','Rocket']; } } let topMode='referrers';
let cachedCountry = null;

function initData(){ return tg?.initData || ''; }
async function api(action,data={}){
 try{
  const _photo = tg?.initDataUnsafe?.user?.photo_url || '';
  const body=new URLSearchParams({action,initData:initData(),start_param:tg?.initDataUnsafe?.start_param||'',photo_url:_photo,...data});
  const r=await fetch(`${BOT_API}?api=1`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Telegram-Init-Data':initData()},body});
  const text=await r.text();
  try{return JSON.parse(text);}catch{return{ok:false,message:'Invalid response'};}
 }catch(e){return{ok:false,message:'Network error'};}
}
function toast(msg){ if(!toastEl)return; toastEl.textContent=msg||'Done'; toastEl.style.display='block'; clearTimeout(window._toast); window._toast=setTimeout(()=>{toastEl.style.display='none';},3500); }
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function money(n){return Number(n||0).toFixed(2);}
function userName(){return(state.user?.name||'User');}
function userBalance(){return Number(state.user?.balance||0);}
function userTodayViews(){return Number(state.user?.today_views||0);} function userTotalViews(){ return Number(state.user?.daily_total_views ?? state.user?.total_views ?? 0); }
function userReferrals(){return Number(state.user?.referrals||0);}
function userEarned(){return Number(state.user?.earned||0);}
function userFakeCount(){return Number(state.user?.fake_count||0);}
function userGoodCount(){return Number(state.user?.good_count||0);}

let _poroMem = null; let _lijentMem = null;
function getPoroViews(){ 
  try{
    if(state.user?.poro_views!==undefined){ 
      const srv = Number(state.user.poro_views||0);
      _poroMem=srv; 
      try{ localStorage.setItem('poro_views_v2', String(srv)); }catch{}
      return srv; 
    }
  }catch{}
  if(_poroMem!==null) return _poroMem; 
  try{const v=localStorage.getItem('poro_views_v2'); _poroMem=v?parseInt(v)||0:0; return _poroMem;}catch(e){return 0;} }
function getLijentViews(){ 
  try{
    if(state.user?.lijent_views!==undefined){ 
      const srv = Number(state.user.lijent_views||0);
      _lijentMem=srv; 
      try{ localStorage.setItem('lijent_views_v2', String(srv)); }catch{}
      return srv; 
    }
  }catch{}
  if(_lijentMem!==null) return _lijentMem; 
  try{const v=localStorage.getItem('lijent_views_v2'); _lijentMem=v?parseInt(v)||0:0; return _lijentMem;}catch(e){return 0;} }
function savePoroViews(n){ _poroMem=n; try{localStorage.setItem('poro_views_v2',String(n));}catch(e){} }
function saveLijentViews(n){ _lijentMem=n; try{localStorage.setItem('lijent_views_v2',String(n));}catch(e){} }
function getPoroMax(){ return Number(state.poro_limit||state.settings?.poro_limit||100); } function getLijentMax(){ return Number(state.lijent_limit||state.settings?.lijent_limit||100); }
function getLocalCounts(){ try{ const uid=userId||state.user?.id||'guest'; const key='earn_counts_'+uid; const raw=localStorage.getItem(key); if(raw){const d=JSON.parse(raw); return {fake:Number(d.fake||0),good:Number(d.good||0)};} }catch(e){} return {fake:0,good:0}; }
function saveLocalCounts(fake,good){ try{const uid=userId||state.user?.id||'guest'; const key='earn_counts_'+uid; localStorage.setItem(key,JSON.stringify({fake,good,updated:Date.now()}));}catch(e){} }
function incLocalFake(){ const c=getLocalCounts(); c.fake+=1; saveLocalCounts(c.fake,c.good); if(state.user) state.user.fake_count=(Number(state.user.fake_count||0)+1); updateBoxUI(); }
function incLocalGood(){ const c=getLocalCounts(); c.good+=1; saveLocalCounts(c.fake,c.good); if(state.user) state.user.good_count=(Number(state.user.good_count||0)+1); updateBoxUI(); }
function updateBoxUI(){ const fakeEl=document.getElementById('fakeNum'); const goodEl=document.getElementById('goodNum'); const fakeCount=state.user?.fake_count??getLocalCounts().fake; const goodCount=state.user?.good_count??getLocalCounts().good; if(fakeEl) fakeEl.textContent=fakeCount; if(goodEl) goodEl.textContent=goodCount; }
function getLast7DaysData(){ const out=[]; const now=new Date(); for(let i=6;i>=0;i--){const d=new Date(now); d.setDate(now.getDate()-i); const dayStr=String(d.getDate()).padStart(2,'0'); const full=d.toISOString().split('T')[0]; let earn=0; if(state.earnings_history){const found=state.earnings_history.find(x=>x.full_date===full); if(found) earn=found.earn;} out.push({date:dayStr,full_date:full,earn});} return out;}
function saveDailyEarn(amount){ try{const now=new Date(); const dhakaNow=new Date(now.toLocaleString('en-US',{timeZone:'Asia/Dhaka'})); if(dhakaNow.getHours()<6) dhakaNow.setDate(dhakaNow.getDate()-1); const today=dhakaNow.getFullYear()+'-'+String(dhakaNow.getMonth()+1).padStart(2,'0')+'-'+String(dhakaNow.getDate()).padStart(2,'0'); if(!state.earnings_history) state.earnings_history=getLast7DaysData(); for(let item of state.earnings_history){if(item.full_date===today){item.earn+=Number(amount||0); break;}}}catch(e){} }
function drawEarnChart(hist){
  try{
    const canvas=document.getElementById('earnChart'); if(!canvas) return;
    const ctx=canvas.getContext('2d'); const dpr=window.devicePixelRatio||1; const rect=canvas.getBoundingClientRect();
    canvas.width=rect.width*dpr; canvas.height=150*dpr; ctx.scale(dpr,dpr);
    const W=rect.width, H=150; ctx.clearRect(0,0,W,H);
    if(!hist||!hist.length) return;
    const maxVal=Math.max(...hist.map(h=>h.earn),5); const padding=10; const barW=(W-padding*2)/hist.length-8;
    hist.forEach((h,i)=>{ const x=padding+i*((W-padding*2)/hist.length); const barH=Math.max(4,(h.earn/maxVal)*(H-22)); const y=H-barH-14; const grad=ctx.createLinearGradient(0,y,0,y+barH); grad.addColorStop(0,'#12c9e7'); grad.addColorStop(1,'#665cf4'); ctx.fillStyle=grad; ctx.beginPath(); ctx.roundRect(x,y,barW,barH,6); ctx.fill(); if(h.earn>0){ctx.fillStyle='#7c8da8'; ctx.font='10px system-ui'; ctx.textAlign='center'; ctx.fillText(money(h.earn), x+barW/2, y-4);} });
  }catch(e){}
}
let audioCtx=null; function getAudioCtx(){ if(!audioCtx){try{audioCtx=new (window.AudioContext||window.webkitAudioContext)();}catch(e){return null;}} return audioCtx; }
function playTok(){ try{const ctx=getAudioCtx(); if(!ctx)return; const o=ctx.createOscillator(); const g=ctx.createGain(); o.type='sine'; o.frequency.value=900; o.connect(g); g.connect(ctx.destination); g.gain.setValueAtTime(0.4,ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.01,ctx.currentTime+0.35); o.start(); o.stop(ctx.currentTime+0.35);}catch(e){} }
function playWarningSound(){ try{const ctx=getAudioCtx(); if(!ctx)return; const o=ctx.createOscillator(); const g=ctx.createGain(); o.type='sawtooth'; o.frequency.value=200; o.connect(g); g.connect(ctx.destination); g.gain.setValueAtTime(0.3,ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.01,ctx.currentTime+0.5); o.start(); o.stop(ctx.currentTime+0.5);}catch(e){} }
async function getUserCountry(force=false){
  if(cachedCountry&&!force) return cachedCountry;
  try{const r=await fetch('https://ipwho.is/'); const d=await r.json(); if(d&&d.country_code){cachedCountry={code:d.country_code,name:d.country,ip:d.ip}; return cachedCountry;}}catch(e){}
  try{const r=await fetch('https://ipapi.co/json/'); const d=await r.json(); if(d&&d.country_code){cachedCountry={code:d.country_code,name:d.country_name,ip:d.ip}; return cachedCountry;}}catch(e){}
  return null;
}

function hero(){
 const telegramName=[tg?.initDataUnsafe?.user?.first_name,tg?.initDataUnsafe?.user?.last_name].filter(Boolean).join(' ')||tg?.initDataUnsafe?.user?.username||userName();
 const cleanName=telegramName.replace(/[^\w\s\u0000-\u007F]/g,'').trim()||telegramName||'User';
 const telegramPhoto=tg?.initDataUnsafe?.user?.photo_url||state.user?.photo_url||'';
 const firstLetter=(cleanName||'U').charAt(0).toUpperCase();
 let avatarContent='';
 if(telegramPhoto){
   avatarContent=`<img src="${esc(telegramPhoto)}" alt="${esc(cleanName)}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"><div class="avatar-fallback" style="display:none;width:100%;height:100%;place-items:center;font-size:28px;font-weight:900;background:linear-gradient(135deg,#2ea8ff,#a855f7);color:#fff;border-radius:50%;">${esc(firstLetter)}</div>`;
 } else {
   avatarContent=`<div class="avatar-fallback" style="width:100%;height:100%;display:grid;place-items:center;font-size:28px;font-weight:900;background:linear-gradient(135deg,#2ea8ff,#a855f7);color:#fff;border-radius:50%;">${esc(firstLetter)}</div>`;
 }
 return `<section class="hero"><div class="avatar-wrap"><div class="avatar" style="overflow:hidden;">${avatarContent}</div><div class="verified-badge">✓</div></div><div class="name">${esc(cleanName)}</div><div class="balance-pill">Balance: <span id="balanceText">${money(userBalance())} TK</span></div></section>`;
}
function earnHero(){
 const telegramName=[tg?.initDataUnsafe?.user?.first_name,tg?.initDataUnsafe?.user?.last_name].filter(Boolean).join(' ')||tg?.initDataUnsafe?.user?.username||userName();
 const cleanName=telegramName.replace(/[^\w\s\u0000-\u007F]/g,'').trim()||telegramName||'User';
 const telegramPhoto=tg?.initDataUnsafe?.user?.photo_url||state.user?.photo_url||'';
 const firstLetter=(cleanName||'U').charAt(0).toUpperCase();
 let avatarContent='';
 if(telegramPhoto){
   avatarContent=`<img src="${esc(telegramPhoto)}" alt="${esc(cleanName)}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"><div class="avatar-fallback" style="display:none;width:100%;height:100%;place-items:center;font-size:32px;font-weight:900;">${esc(firstLetter)}</div>`;
 } else {
   avatarContent=`<div class="avatar-fallback" style="width:100%;height:100%;display:grid;place-items:center;font-size:32px;font-weight:900;background:linear-gradient(135deg,#2ea8ff,#a855f7);color:#fff;border-radius:50%;">${esc(firstLetter)}</div>`;
 }
 const local=getLocalCounts(); const fakeCount=state.user?.fake_count??local.fake; const goodCount=state.user?.good_count??local.good;
 return `<section class="hero"><div class="hero-earn-row"><div class="hero-box fake"><div class="box-num" id="fakeNum">${fakeCount}</div><div class="box-label">Fake Kaj</div></div><div class="avatar-wrap"><div class="avatar" style="overflow:hidden;">${avatarContent}</div><div class="verified-badge">✓</div></div><div class="hero-box good"><div class="box-num" id="goodNum">${goodCount}</div><div class="box-label">Good Working</div></div></div><div class="name">${esc(cleanName)}</div><div class="earn-balance-vpn-row"><div class="balance-pill">Balance: <span id="balanceText">${money(userBalance())} TK</span></div><a href="https://play.google.com/store/apps/details?id=free.vpnaustralia.unlimited.tunnel.proxy.secure.hotspot" target="_blank" class="vpn-round-btn">VPN</a></div><div class="kaj-vpn-text-below">KAJ KORAR VPN</div></section>`;
}
function heroHomeWithAdmin(){
 const telegramName=[tg?.initDataUnsafe?.user?.first_name,tg?.initDataUnsafe?.user?.last_name].filter(Boolean).join(' ')||tg?.initDataUnsafe?.user?.username||userName();
 const cleanName=telegramName.replace(/[^\w\s\u0000-\u007F]/g,'').trim()||telegramName||'User';
 const telegramPhoto=tg?.initDataUnsafe?.user?.photo_url||state.user?.photo_url||'';
 const firstLetter=(cleanName||'U').charAt(0).toUpperCase();
 let avatarContent='';
 if(telegramPhoto){
   avatarContent=`<img src="${esc(telegramPhoto)}" alt="${esc(cleanName)}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"><div class="avatar-fallback" style="display:none;width:100%;height:100%;place-items:center;font-size:26px;font-weight:900;background:linear-gradient(135deg,#2ea8ff,#a855f7);color:#fff;border-radius:50%;">${esc(firstLetter)}</div>`;
 } else {
   avatarContent=`<div class="avatar-fallback" style="width:100%;height:100%;display:grid;place-items:center;font-size:26px;font-weight:900;background:linear-gradient(135deg,#2ea8ff,#a855f7);color:#fff;border-radius:50%;">${esc(firstLetter)}</div>`;
 }
 return `<section class="hero home-hero-admin"><div class="home-hero-row"><div class="dev-card"><div class="dev-label" style="font-size:13px;font-weight:800;letter-spacing:1px">DEVELOPER</div><div class="dev-avatar"><img src="${DEV_PIC}" alt="Developer" style="width:100%;height:100%;object-fit:cover;" /></div><div style="font-size:18px;font-weight:900;color:#fff;margin-top:8px;letter-spacing:0.5px;text-transform:uppercase">E NOYON</div></div><div class="user-card"><div class="avatar-wrap"><div class="avatar" style="overflow:hidden;">${avatarContent}</div><div class="verified-badge">✓</div></div><div class="name">${esc(cleanName)}</div><div class="balance-pill">Balance: <span id="balanceText">${money(userBalance())} TK</span></div></div></div></section>`;
}

function ensureAdminPanel(){
  if(document.getElementById('adminPanel')) return;
  const div=document.createElement('div'); div.id='adminPanel'; div.className='overlay hidden'; div.style.display='none'; div.style.position='fixed'; div.style.inset='0'; div.style.zIndex='9999'; div.style.background='rgba(7,20,38,0.92)'; div.style.placeItems='start center'; div.style.padding='12px'; div.style.overflowY='auto';
  div.innerHTML=`
  <div style="background:#0e1f35;border:1px solid #1d3048;border-radius:18px;padding:0;width:min(96%,480px);max-height:95vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,0.6);margin-top:20px;">
    <div style="display:flex;justify-content:space-between;align-items:center;padding:16px 18px;border-bottom:1px solid #1d3048;position:sticky;top:0;background:#0e1f35;z-index:2;">
      <h3 style="margin:0;color:#fff;font-size:18px;font-weight:900;">⚙️ Admin Panel</h3>
      <button onclick="closeAdminPanel()" style="background:#0a172b;border:1px solid #2a4a6b;color:#fff;width:32px;height:32px;border-radius:50%;cursor:pointer;">✕</button>
    </div>
    <div style="display:flex;gap:6px;padding:10px 12px;overflow-x:auto;border-bottom:1px solid #1d3048;background:#0a172b;">
      <button onclick="switchAdminTab('settings')" id="admTab_settings" class="admTab active" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#1ec8e8;color:#fff;font-weight:700;white-space:nowrap;cursor:pointer;">Settings</button>
      <button onclick="switchAdminTab('adnetwork')" id="admTab_adnetwork" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">📢 Ad Network Control</button>
      <button onclick="switchAdminTab('limits')" id="admTab_limits" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Limits</button>
      <button onclick="switchAdminTab('withdraw')" id="admTab_withdraw" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Withdraw</button>
      <button onclick="switchAdminTab('users')" id="admTab_users" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Users</button>
      <button onclick="switchAdminTab('payment')" id="admTab_payment" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Payment</button>
      <button onclick="switchAdminTab('search')" id="admTab_search" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Search</button>
      <button onclick="switchAdminTab('datareset')" id="admTab_datareset" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Data Reset</button>
      <button onclick="switchAdminTab('notices')" id="admTab_notices" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Notices</button>
      <button onclick="switchAdminTab('bonus')" id="admTab_bonus" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Bonus Tasks</button>
      <button onclick="switchAdminTab('daily')" id="admTab_daily" class="admTab" style="padding:8px 12px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;white-space:nowrap;cursor:pointer;">Daily</button>
    </div>
    <div style="padding:16px;overflow-y:auto;flex:1;">
      <div id="admContent_settings" class="admContent">
        <div style="display:flex;flex-direction:column;gap:12px;">
          <label style="color:#8aa0bb;font-size:13px;">Poro Reward (TK)<input id="adminPoroReward" class="input" type="number" placeholder="5" style="margin-top:6px"></label>
          <label style="color:#8aa0bb;font-size:13px;">Lijent Reward (TK)<input id="adminLijentReward" class="input" type="number" placeholder="7" style="margin-top:6px"></label>
          <label style="color:#8aa0bb;font-size:13px;">Min Withdraw (TK)<input id="adminMinWithdraw" class="input" type="number" placeholder="100" style="margin-top:6px"></label>
          <label style="color:#8aa0bb;font-size:13px;">Minimum USDT<input id="adminMinUsdt" class="input" type="number" step="0.01" placeholder="1" style="margin-top:6px"></label>
          <label style="color:#8aa0bb;font-size:13px;">Minimum Recharge (TK)<input id="adminMinRecharge" class="input" type="number" step="0.01" placeholder="20" style="margin-top:6px"></label>
          <label style="color:#8aa0bb;font-size:13px;">Allowed Countries (comma)<input id="adminAllowedCountries" class="input" type="text" placeholder="BD,US,AU" style="margin-top:6px"></label>
          <button id="adminSaveBtn" class="gradient-btn" onclick="saveAdminSettings()" style="margin-top:6px;">Save Settings</button>
        </div>
      </div>
      <div id="admContent_adnetwork" class="admContent" style="display:none;">
        <div style="display:flex;flex-direction:column;gap:12px;">
          <div style="background:#0a172b;border:1px solid #1d3048;border-radius:12px;padding:14px;">
            <div style="color:#fff;font-weight:900;font-size:15px;">💎 Monetag Poro</div>
            <div style="color:#8aa0bb;font-size:12px;margin-top:4px;line-height:1.5;">Code/SDK link এখানে রাখুন। খালি রাখলে Poro Earn বন্ধ থাকবে।</div>
            <textarea id="adminMonetagCode" class="input" rows=4 placeholder="&lt;script src='//libtl.com/sdk.js' data-zone='10483352' data-sdk='show_10483352'&gt;&lt;/script&gt;" style="margin-top:8px;resize:vertical;min-height:90px;"></textarea>
          </div>
          <div style="background:#0a172b;border:1px solid #1d3048;border-radius:12px;padding:14px;">
            <div style="color:#fff;font-weight:900;font-size:15px;">⚡ AdSpark Lijent</div>
            <div style="color:#8aa0bb;font-size:12px;margin-top:4px;line-height:1.5;">SDK code/link এখানে রাখুন। খালি রাখলে Lijent Earn বন্ধ থাকবে।</div>
            <textarea id="adminAdsparkCode" class="input" rows=3 placeholder="https://adspark-tma.top/api/public/sdk.js?k=34" style="margin-top:8px;resize:vertical;min-height:75px;"></textarea>
          </div>
          <div style="background:#101f33;border:1px solid #25415f;border-radius:10px;padding:10px;color:#9fb3cc;font-size:12px;line-height:1.5;">ℹ️ দুইটাই চালু রাখতে দুই box-এই code/link রাখুন। কোনো network বন্ধ করতে শুধু সেই box খালি করে Save করুন।</div>
          <button id="adminAdNetworkSaveBtn" class="gradient-btn" onclick="saveAdminSettings()" style="margin-top:2px;">💾 Save Ad Network Settings</button>
        </div>
      </div>
      <div id="admContent_limits" class="admContent" style="display:none;">
        <div style="display:flex;flex-direction:column;gap:12px;">
          <div style="background:#0a172b;border:1px solid #1d3048;border-radius:10px;padding:12px;"><div style="color:#fff;font-weight:800;">Poro Earn Limit</div><input id="adminPoroLimit" class="input" type="number" placeholder="70" style="margin-top:8px"></div>
          <div style="background:#0a172b;border:1px solid #1d3048;border-radius:10px;padding:12px;"><div style="color:#fff;font-weight:800;">Lijent Earn Limit</div><input id="adminLijentLimit" class="input" type="number" placeholder="37" style="margin-top:8px"></div>
          <button id="adminLimitSaveBtn" class="gradient-btn" onclick="saveAdminLimits()" style="margin-top:6px;">Save Limits</button>
          <div style="border-top:1px dashed #1d3048;margin-top:8px;padding-top:12px;">
            <button class="gradient-btn" onclick="resetAllAdsAdmin()" style="background:linear-gradient(90deg,#ff3c3c,#ff8a00);">🔄 Reset All Users Ads</button>
          </div>
        </div>
      </div>
      <div id="admContent_withdraw" class="admContent" style="display:none;">
        <div style="display:flex;gap:8px;margin-bottom:12px;">
          <button onclick="loadWithdraws('pending')" id="wdTab_pending" class="wdTab active" style="flex:1;padding:8px;border-radius:8px;border:1px solid #f1c40f;background:#f1c40f;color:#000;font-weight:700;">Pending</button>
          <button onclick="loadWithdraws('approved')" id="wdTab_approved" class="wdTab" style="flex:1;padding:8px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;">Approved</button>
          <button onclick="loadWithdraws('rejected')" id="wdTab_rejected" class="wdTab" style="flex:1;padding:8px;border-radius:8px;border:1px solid #1d3048;background:#0e1f35;color:#8aa0bb;">Rejected</button>
        </div>
        <div id="withdrawList" style="display:flex;flex-direction:column;gap:10px;max-height:400px;overflow-y:auto;">Loading...</div>
      </div>
      <div id="admContent_users" class="admContent" style="display:none;">
        <button class="gradient-btn" onclick="loadUsers()" style="margin-bottom:12px;">🔄 Load Users</button>
        <div id="usersList" style="display:flex;flex-direction:column;gap:8px;max-height:400px;overflow-y:auto;">Click Load</div>
      </div>
      <div id="admContent_notices" class="admContent" style="display:none;">
        <div style="display:flex;flex-direction:column;gap:14px;">
          <label style="color:#8aa0bb;font-size:13px;">Welcome Notice<textarea id="adminWelcomeNotice" class="input" style="min-height:100px;margin-top:6px;resize:vertical;"></textarea></label>
          <label style="color:#8aa0bb;font-size:13px;">Earning Popup Notice<textarea id="adminEarningPopup" class="input" style="min-height:100px;margin-top:6px;resize:vertical;"></textarea></label>
          <label style="color:#8aa0bb;font-size:13px;">Rules Update Notice<textarea id="adminBonusText" class="input" style="min-height:80px;margin-top:6px;resize:vertical;"></textarea></label>
          <button class="gradient-btn" onclick="saveNotices()">Save Notices</button>
          <button class="gradient-btn" onclick="saveNoticeAdSet()">Add Notice Set</button>
          <button class="gradient-btn" onclick="saveNoticeAddSecondSet()">Notice Add Second Set</button>
          <button class="gradient-btn" onclick="saveHomeNotice()">Home Notice Set</button>
        </div>
      </div>
      <div id="admContent_payment" class="admContent" style="display:none;"><div style="display:flex;flex-direction:column;gap:12px;"><h3 style="margin:0;color:#fff;">Payment Methods</h3><div style="font-size:12px;color:#8aa0bb;line-height:1.6;">Code দিন: <b>BK</b>=bKash, <b>NG</b>=Nagad, <b>RK</b>=Rocket, <b>BC</b>=Binance, <b>RC</b>=Mobile Recharge</div><input id="adminPaymentInput" class="input" placeholder="Ex: NG, BK, RK, BC, RC"><button class="gradient-btn" onclick="savePaymentMethods()">Save Payment Methods</button><div id="paymentPreview" style="background:#0a172b;border:1px solid #1d3048;border-radius:8px;padding:10px;color:#fff;font-size:13px;">Preview</div></div></div><div id="admContent_search" class="admContent" style="display:none;"><div style="display:flex;flex-direction:column;gap:12px;"><h3 style="margin:0;color:#fff;">User ID Search</h3><input id="adminSearchUid" class="input" type="number" placeholder="Enter User ID"><button class="gradient-btn" onclick="searchUserById()">Search User</button><div id="adminSearchResult" style="display:flex;flex-direction:column;gap:8px;">No search yet</div></div></div><div id="admContent_datareset" class="admContent" style="display:none;"><div style="display:flex;flex-direction:column;gap:14px;"><h3 style="margin:0;color:#fff;">All User Data Reset</h3><div style="background:#2a1a1a;border:1px solid #ff4d4d;border-radius:8px;padding:12px;color:#ffaaaa;font-size:13px;">Balance, Good, Fake thakbe. Withdraw, history, daily clear hobe. Bot fast hobe.</div><button onclick="resetAllUserData()" style="padding:12px;border-radius:8px;border:0;background:#ff4d4d;color:#fff;font-weight:900;">Reset All User Data</button><div id="dataResetResult" style="color:#8aa0bb;font-size:12px;"></div></div></div><div id="admContent_bonus" class="admContent" style="display:none;">
        <div style="display:flex;flex-direction:column;gap:14px;">
          <div style="font-weight:900;color:#fff;font-size:18px;">🎁 Bonus Tasks Manager</div>
          <div style="background:#0a172b;border:1px solid #1d3048;border-radius:12px;padding:14px;">
            <div style="color:#fff;font-weight:700;font-size:13px;">Task Title</div>
            <input id="adminBonusTitle" class="input" type="text" placeholder="সম্পূর্ণ ভিডিও দেখুন" style="margin-top:6px;">
            <div style="color:#fff;font-weight:700;font-size:13px;margin-top:10px;">Task URL</div>
            <input id="adminBonusUrl" class="input" type="text" placeholder="https://t.me/SmartWorkCommunity" style="margin-top:6px;">
            <div style="color:#fff;font-weight:700;font-size:13px;margin-top:10px;">Task Type</div>
            <select id="adminBonusType" class="input" style="margin-top:6px;"><option value="subscribe">Subscribe/Join Type</option><option value="video">Video Watch Type</option></select>
            <div style="color:#fff;font-weight:700;font-size:13px;margin-top:10px;">Required Watch Time (Seconds)</div>
            <input id="adminBonusWatchTime" class="input" type="number" min="0.15" max="3600" step="0.01" value="5" placeholder="5" style="margin-top:6px;">
            <div style="color:#fff;font-weight:700;font-size:13px;margin-top:10px;">Reward TK</div>
            <input id="adminBonusReward" class="input" type="number" step="0.1" value="0.5" style="margin-top:6px;">
            <button onclick="addAdminBonusTask()" style="width:100%;padding:12px;background:#00c851;color:#fff;border:0;border-radius:10px;font-weight:900;margin-top:14px;font-size:15px;">➕ Add Task</button>
          </div>
          <div id="adminBonusList" style="margin-top:12px;"></div>
        </div>
      </div>
      <div id="admContent_daily" class="admContent" style="display:none;">
        <div style="display:flex;flex-direction:column;gap:12px;">
          <div style="background:#0a172b;border:1px solid #1d3048;border-radius:10px;padding:12px;"><div style="color:#fff;font-weight:800;">Daily Active Users</div><button class="gradient-btn" onclick="loadDailyActive()" style="margin-top:10px;">Load Daily Active</button><div id="dailyActiveList" style="margin-top:12px;"></div></div>
        </div>
      </div>
    </div>
    <div style="padding:12px;border-top:1px solid #1d3048;"><button class="gradient-btn" onclick="closeAdminPanel()" style="background:#1d3048;">Close Panel</button></div>
  </div>`;
  document.body.appendChild(div);
}
async function saveNoticeAdSet(){
  const current = Number(window._noticeAdSet || 5);
  const value = prompt('Add Notice Set (Ads):', String(current));
  if(value===null) return;
  const n = Number(value);
  if(!Number.isInteger(n) || n < 1){ toast('Enter a valid ad number'); return; }
  try{
    const res = await api('admin_save_settings',{settings:JSON.stringify({notice_ad_set:n})});
    if(res && res.ok){ window._noticeAdSet=n; toast('Add Notice Set saved: '+n); }
    else { toast(res?.message||'Failed'); }
  }catch(e){ toast('Failed'); }
}
window.saveNoticeAdSet=saveNoticeAdSet;
async function saveNoticeAddSecondSet(){
  const current = Number(window._noticeAddSecondSet || 30);
  const value = prompt('Notice Add Second Set:', String(current));
  if(value===null) return;
  const n = Number(value);
  if(!Number.isFinite(n) || n < 1){ toast('Enter valid seconds'); return; }
  try{
    const res = await api('admin_save_settings',{settings:JSON.stringify({notice_add_second_set:n})});
    if(res && res.ok){ window._noticeAddSecondSet=n; toast('Notice Add Second Set saved: '+n+' seconds'); }
    else { toast(res?.message||'Failed'); }
  }catch(e){ toast('Failed'); }
}
window.saveNoticeAddSecondSet=saveNoticeAddSecondSet;
async function saveHomeNotice(){
  const currentCountry = String(window._homeNoticeCountry || 'Australia');
  const currentText = String(window._homeNoticeText || '');
  const country = prompt('Home Notice Country:', currentCountry);
  if(country === null) return;
  const text = prompt('Home Notice Text:', currentText);
  if(text === null) return;
  try{
    const res = await api('admin_save_settings',{settings:JSON.stringify({home_notice:'',home_notice_country:country.trim(),home_notice_text:text})});
    if(res && res.ok){ window._homeNotice=''; window._homeNoticeCountry=country.trim()||'Australia'; window._homeNoticeText=text; toast('Home Notice saved'); }
    else toast('Save failed');
  }catch(e){ toast('Save failed'); }
}
window.saveHomeNotice=saveHomeNotice;


function switchAdminTab(tab){
  document.querySelectorAll('.admTab').forEach(b=>{b.style.background='#0e1f35'; b.style.color='#8aa0bb'; b.classList.remove('active');});
  const activeBtn=document.getElementById('admTab_'+tab); if(activeBtn){activeBtn.style.background='#1ec8e8'; activeBtn.style.color='#fff'; activeBtn.classList.add('active');}
  document.querySelectorAll('.admContent').forEach(c=>c.style.display='none');
  const content=document.getElementById('admContent_'+tab); if(content) content.style.display='block';
  if(tab==='withdraw') loadWithdraws('pending');
  if(tab==='daily') loadDailyActive();
}
window.switchAdminTab=switchAdminTab;
async function saveAdminLimits(){
  const btn=document.getElementById('adminLimitSaveBtn');
  const poroLim=document.getElementById('adminPoroLimit')?.value;
  const lijentLim=document.getElementById('adminLijentLimit')?.value;
  const settings={poro_limit:Number(poroLim||100), lijent_limit:Number(lijentLim||100)};
  if(btn){btn.textContent='Saving...'; btn.disabled=true;}
  try{
    const res=await api('admin_save_settings',{settings:JSON.stringify(settings)});
    state.poro_limit=settings.poro_limit; 
    state.lijent_limit=settings.lijent_limit;
    state.settings = state.settings || {};
    state.settings.poro_limit = settings.poro_limit;
    state.settings.lijent_limit = settings.lijent_limit;
    try{ localStorage.setItem('admin_settings_v1', JSON.stringify(settings)); }catch(e){}
    try{ localStorage.setItem('admin_settings_cache', JSON.stringify(settings)); }catch(e){}
    setTimeout(()=>{
      const poroEl=document.getElementById('poroCount');
      const lijentEl=document.getElementById('lijentCount');
      const homeL=document.getElementById('homeAdLijent');
      const homeP=document.getElementById('homeAdPoro');
      if(poroEl) poroEl.textContent=`${getPoroViews()}/${getPoroMax()}`;
      if(lijentEl) lijentEl.textContent=`${getLijentViews()}/${getLijentMax()}`;
      if(homeL) homeL.textContent=`${getLijentViews()}/${getLijentMax()} AD`;
      if(homeP) homeP.textContent=`${getPoroViews()}/${getPoroMax()} MG`;
    },500);
    if(res && res.ok){
      toast('Limits saved & updated instantly ✅ '+settings.poro_limit+'/'+settings.lijent_limit);
    } else { 
      toast('Saved & Applied instantly ✅');
    }
  }catch(e){toast('Save failed: '+(e?.message||''));} finally { if(btn){btn.textContent='Save Limits'; btn.disabled=false;} }
}
window.saveAdminLimits=saveAdminLimits;
async function resetAllAdsAdmin(){
  if(!confirm('Are you sure?')) return;
  try{
    const res=await api('admin_reset_all_ads');
    if(res && res.ok){ 
      try{
        localStorage.setItem('poro_views_v2','0'); localStorage.setItem('lijent_views_v2','0');
        _poroMem=0; _lijentMem=0;
      }catch{}
      if(state.user){ state.user.poro_views=0; state.user.lijent_views=0; }
      const poroEl=document.getElementById('poroCount'); const lijentEl=document.getElementById('lijentCount');
      if(poroEl) poroEl.textContent=`0/${getPoroMax()}`;
      if(lijentEl) lijentEl.textContent=`0/${getLijentMax()}`;
      await load();
      renderTasks();
      toast('Reset Done ✅');
    } else { toast(res?.message||'Failed'); }
  }catch(e){toast('Failed');}
}
window.resetAllAdsAdmin=resetAllAdsAdmin;
async function loadWithdraws(status='pending'){
  document.querySelectorAll('.wdTab').forEach(b=>{b.style.background='#0e1f35'; b.style.color='#8aa0bb'; b.style.borderColor='#1d3048'; b.classList.remove('active');});
  const activeBtn=document.getElementById('wdTab_'+status); if(activeBtn){activeBtn.style.background=status==='pending'?'#f1c40f':(status==='approved'?'#2ecc71':'#e74c3c'); activeBtn.style.color=status==='pending'?'#000':'#fff'; activeBtn.classList.add('active');}
  const listEl=document.getElementById('withdrawList'); if(!listEl) return; listEl.innerHTML='Loading...';
  try{
    const res=await api('admin_get_withdraws',{status:status});
    if(!res.ok){ listEl.innerHTML='Failed'; return; }
    const arr=res.withdraws||[]; if(arr.length===0){ listEl.innerHTML='<div style="color:#7c8da8;text-align:center;padding:20px;">No '+esc(status)+' withdraws</div>'; return; }
    let html='';
    for(const w of arr){
      let dateStr='';
      try{
        const d = new Date(w.created_at);
        const dd = String(d.getDate()).padStart(2,'0');
        const mm = String(d.getMonth()+1).padStart(2,'0');
        const yyyy = d.getFullYear();
        let hh = d.getHours();
        const ampm = hh>=12?'PM':'AM';
        hh = hh%12; if(hh===0) hh=12;
        const min = String(d.getMinutes()).padStart(2,'0');
        const sec = String(d.getSeconds()).padStart(2,'0');
        dateStr = `${dd}/${mm}/${yyyy}, ${hh}:${min}:${sec} ${ampm}`;
      }catch(e){ dateStr = w.created_at||''; }
      const good = w.good_count!==undefined? w.good_count : (w.good!==undefined? w.good : 0);
      const fake = w.fake_count!==undefined? w.fake_count : (w.fake!==undefined? w.fake : 0);
      html+=`<div style="background:#0a172b;border:1px solid #1d3048;border-radius:12px;padding:12px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
          <div style="flex:1;"><div style="font-weight:800;color:#fff;">${esc(w.name||'User')} - ID:${esc(String(w.user_id||''))}</div><div style="font-size:13px;color:#fff;margin-top:4px;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">${paymentMethodLabelClient(w.method)==='Binance' ? `${w.amount} USDT` : `${w.amount} TK`} - ${esc(paymentMethodLabelClient(w.method))} - <span>${esc(w.account||'')}</span>${w.account?`<button onclick="copyWithdrawAccount('${esc(String(w.account).replace(/'/g,"&#39;"))}')" style="padding:3px 7px;border-radius:5px;border:1px solid #1d3048;background:#162b45;color:#4fc3f7;font-size:11px;font-weight:800;cursor:pointer;">Copy</button>`:''}</div><div style="font-size:12px;color:#00e676;margin-top:6px;font-weight:700;">Good:${good} | Fake:${fake} | Bal:${w.balance_after!==undefined?w.balance_after:(w.balance||0)} TK</div><div style="font-size:11px;color:#7a8ca8;margin-top:4px;">${esc(dateStr)}</div></div>
          <div style="display:flex;flex-direction:column;gap:6px;">${(w.status==='pending')?`<button onclick="processWithdraw('${w.id}','approve')" style="padding:6px 10px;border-radius:6px;border:0;background:#2ecc71;color:#fff;font-weight:700;">Approve</button><button onclick="processWithdraw('${w.id}','reject')" style="padding:6px 10px;border-radius:6px;border:0;background:#e74c3c;color:#fff;font-weight:700;">Reject</button>`:`<span style="padding:4px 8px;border-radius:6px;background:${w.status==='approved'?'#2ecc71':'#e74c3c'};color:#fff;font-size:11px;font-weight:700;">${esc(w.status)}</span>`}</div>
        </div>
      </div>`;
    }
    listEl.innerHTML=html;
  }catch(e){listEl.innerHTML='Failed to load';}
}
window.loadWithdraws=loadWithdraws;
async function copyWithdrawAccount(account){ const value=String(account||'').trim(); if(!value){toast('No number');return;} try{ if(navigator.clipboard) await navigator.clipboard.writeText(value); else { const input=document.createElement('input'); input.value=value; document.body.appendChild(input); input.select(); document.execCommand('copy'); input.remove(); } toast('Number Copied'); }catch(e){toast('Copy failed');} }
window.copyWithdrawAccount=copyWithdrawAccount;
async function processWithdraw(id, decision){
  if(!confirm(decision+' this withdraw?')) return;
  try{
    const res=await api('admin_withdraw_process',{id:id,decision:decision});
    if(res && res.ok){ toast('Withdraw '+decision+'d ✅'); loadWithdraws('pending'); } else { toast(res?.message||'Failed'); }
  }catch(e){toast('Failed');}
}
window.processWithdraw=processWithdraw;
async function loadUsers(){
  const listEl=document.getElementById('usersList'); if(!listEl) return; listEl.innerHTML='Loading...';
  try{
    const res=await api('admin_get_users');
    if(!res.ok){ listEl.innerHTML='Failed'; return; }
    const arr=res.users||[]; if(arr.length===0){ listEl.innerHTML='No users'; return; }
    let html='';
    for(const u of arr.slice(0,100)){
      const isAdminId = Number(u.id)===Number(ADMIN_UID);
      const isOnline = u.is_online;
      const dotColor = isOnline ? '#00ff88' : '#ffcc00';
      const dotTitle = isOnline ? 'Bot er vitore - Online (Sobuj)' : 'Bot er baire - Offline (Holud)';
      const country = u.last_country || u.country || 'BD';
      html+=`<div style="background:#0a172b;border:1px solid #1d3048;border-radius:10px;padding:10px;display:flex;justify-content:space-between;align-items:center;gap:8px;">
        <div style="flex:1;min-width:0;display:flex;align-items:center;gap:8px;"><div style="width:10px;height:10px;border-radius:50%;background:${dotColor};box-shadow:0 0 6px ${dotColor};flex-shrink:0;" title="${dotTitle}"></div><div style="flex:1;min-width:0;"><div style="font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(u.name||'User')} - ${u.id} ${isAdminId?'<span style="color:#00e5ff;">(Admin)</span>':''} <span style="background:#0e2a4a;border:1px solid #1d5a8a;color:#00e5ff;padding:2px 6px;border-radius:4px;font-size:10px;margin-left:4px;">${esc(country)}</span></div><div style="font-size:12px;color:#8aa0bb;margin-top:2px;">Bal: ${u.balance||0} TK | Good:${u.good_count||0} Fake:${u.fake_count||0} ${u.banned?'<span style="color:#ff6b6b;">BANNED</span>':''} | Country: ${esc(country)}</div></div></div>
        <div style="display:flex;gap:6px;flex-shrink:0;"><button onclick="editUserBal(${u.id})" style="padding:6px 8px;border-radius:6px;border:1px solid #1d3048;background:#0e1f35;color:#fff;font-size:11px;">Edit Bal</button>${isAdminId?`<span style="padding:6px 12px;border-radius:6px;background:#00c6ff;color:#fff;font-size:11px;font-weight:900;">Admin</span>`:`<button onclick="toggleBanUser(${u.id}, ${u.banned?0:1})" style="padding:6px 8px;border-radius:6px;border:0;background:${u.banned?'#2ecc71':'#ff6b6b'};color:#fff;font-size:11px;">${u.banned?'Unban':'Ban'}</button>`}</div>
      </div>`;
    }
    listEl.innerHTML=html;
  }catch(e){listEl.innerHTML='Failed';}
}
window.loadUsers=loadUsers;
async function editUserBal(uid){
  const newBal=prompt('Enter new balance for user '+uid+':');
  if(newBal===null) return;
  const bal=Number(newBal);
  if(isNaN(bal)){ alert('Invalid'); return; }
  try{
    const res=await api('admin_edit_user',{user_id:uid,balance:bal});
    if(res && res.ok){ toast('Balance updated ✅'); loadUsers(); } else { toast(res?.message||'Failed'); }
  }catch(e){toast('Failed');}
}
window.editUserBal=editUserBal;
async function toggleBanUser(uid, ban){
  try{
    if(ban){
      if(!confirm('Ei user ke ban korben?\nUser ar bot chalate parbe na, dhuklei "Apni ban khaisen" dekhabe.')) return;
    }
    const res=await api('admin_edit_user',{user_id:uid,ban:ban?1:0});
    if(res && res.ok){ 
      toast(ban?'🚫 User ban hoye gese ✅ - Ar bot chalate parbe na':'✅ User unban kora holo'); 
      loadUsers(); 
    } else { toast(res?.message||'Failed'); }
  }catch(e){toast('Failed: '+(e?.message||''));}
}
window.toggleBanUser=toggleBanUser;
async function loadDailyActive(){
  const el=document.getElementById('dailyActiveList'); if(!el) return; el.innerHTML='Loading...';
  try{
    const res=await api('admin_get_daily_active');
    if(!res.ok){ el.innerHTML='Failed'; return; }
    const arr=res.active||[]; if(arr.length===0){ el.innerHTML='<div style="color:#7c8da8;">No active today</div>'; return; }
    let html=`<div style="color:#7c8da8;font-size:12px;margin-bottom:8px;">Date: ${esc(res.date||'')} - Total: ${arr.length} users (Sobuj=Online, Holud=Offline)</div>`;
    for(const a of arr.slice(0,50)){
      const time=a.last?new Date(a.last*1000).toLocaleTimeString('en-BD',{timeZone:'Asia/Dhaka'}):'';
      const isOnline = a.is_online;
      const dotColor = isOnline ? '#00ff88' : '#ffcc00';
      const dotTitle = isOnline ? 'Bot er vitore ache - Sobuj' : 'Bot er baire - Holud';
      html+=`<div style="background:#0e1f35;border:1px solid #1d3048;border-radius:8px;padding:8px;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;"><div style="display:flex;align-items:center;gap:8px;"><div style="width:10px;height:10px;border-radius:50%;background:${dotColor};box-shadow:0 0 6px ${dotColor};" title="${dotTitle}"></div><div style="color:#fff;font-size:12px;">${esc(a.name||a.id)} - ID:${a.id}</div></div><div style="color:#8aa0bb;font-size:11px;">${a.views} ads - ${time}</div></div>`;
    }
    el.innerHTML=html;
  }catch(e){el.innerHTML='Failed';}
}
window.loadDailyActive=loadDailyActive;
function updatePaymentPreview(raw){
  try{
    const el=document.getElementById('paymentPreview'); if(!el) return;
    const codes=String(raw||'').split(',').map(x=>x.trim()).filter(Boolean);
    const names=codes.map(c=>PAYMENT_MAP[c.toLowerCase()]||c);
    el.innerHTML=names.length ? names.map(n=>`<span style="display:inline-block;padding:5px 8px;margin:2px;border-radius:7px;background:#10263f;border:1px solid #244767;color:#fff;font-weight:800;">${esc(n)}</span>`).join('') : 'No methods';
  }catch(e){}
}
async function savePaymentMethods(){
  var input=document.getElementById('adminPaymentInput'); var val=input?input.value.trim():'';
  if(!val){ toast('Enter methods'); return; }
  try{
    var res=await api('admin_save_payment_methods',{methods:val});
    if(res&&res.ok){
      var savedMethods=String(res.payment_methods||val).toLowerCase();
      toast('Payment saved ✅');
      state.settings=state.settings||{}; state.settings.payment_methods=savedMethods;
      try{ localStorage.setItem('payment_methods_cache', savedMethods); }catch(e){}
      if(input) input.value=savedMethods;
      updatePaymentPreview(savedMethods);
      if(currentTab==='profile') renderProfile();
    } else { toast(res?.message||'Failed'); }
  }catch(e){ toast('Failed'); }
}

async function searchUserById(){
  var el=document.getElementById('adminSearchUid');
  var uid=el?el.value.trim():'';
  if(!uid){ toast('Enter UID'); return; }
  var resultEl=document.getElementById('adminSearchResult');
  if(resultEl) resultEl.innerHTML='Searching...';
  try{
    var res=await api('admin_search_user',{user_id:uid});
    if(res&&res.ok&&res.user){
      var u=res.user;
      var dot=u.is_online?'#00ff88':'#ffcc00';
      var country=u.last_country||u.country||'BD';
      var banned=!!u.banned;
      var isAdminId=Number(u.id)===Number(ADMIN_UID);
      var safeName=esc(u.name||'User');
      var safeId=esc(String(u.id));
      var safeCountry=esc(String(country));
      var balance=Number(u.balance||0).toFixed(2);
      var good=Number(u.good_count||0);
      var fake=Number(u.fake_count||0);
      resultEl.innerHTML=
        '<div style="background:#0e1f35;border:1px solid #1d3048;border-radius:10px;padding:10px;display:flex;justify-content:space-between;align-items:center;gap:8px;">'+
          '<div style="display:flex;align-items:flex-start;gap:8px;flex:1;min-width:0;">'+
            '<div style="width:10px;height:10px;border-radius:50%;background:'+dot+';box-shadow:0 0 6px '+dot+';flex-shrink:0;margin-top:5px;"></div>'+
            '<div style="min-width:0;">'+
              '<div style="color:#fff;font-weight:700;line-height:1.35;">'+
                safeName+' - '+safeId+
                (isAdminId?' <span style="background:#0e2a4a;border:1px solid #1d5a8a;color:#00e5ff;padding:2px 6px;border-radius:4px;font-size:10px;">Admin</span>':'')+
                ' <span style="background:#0e2a4a;border:1px solid #1d5a8a;color:#00e5ff;padding:2px 6px;border-radius:4px;font-size:10px;margin-left:4px;">'+safeCountry+'</span>'+
              '</div>'+
              '<div style="font-size:12px;color:#8aa0bb;margin-top:3px;">Bal: '+balance+' TK | Good:'+good+' Fake:'+fake+' | Country: '+safeCountry+'</div>'+
            '</div>'+
          '</div>'+
          '<div style="display:flex;gap:6px;flex-shrink:0;">'+
            '<button type="button" onclick="editUserBal('+Number(u.id)+')" style="padding:7px 9px;border-radius:7px;border:1px solid #1d3048;background:#12243a;color:#fff;font-size:11px;font-weight:700;">Edit Bal</button>'+
            (isAdminId
              ? '<span style="padding:7px 10px;border-radius:7px;background:#00c6ff;color:#fff;font-size:11px;font-weight:900;">Admin</span>'
              : (banned
                ? '<button type="button" onclick="toggleBanUser('+Number(u.id)+',false)" style="padding:7px 9px;border-radius:7px;border:0;background:#2ecc71;color:#fff;font-size:11px;font-weight:700;">Unban</button>'
                : '<button type="button" onclick="toggleBanUser('+Number(u.id)+',true)" style="padding:7px 9px;border-radius:7px;border:0;background:#ff6262;color:#fff;font-size:11px;font-weight:700;">Ban</button>'))+
          '</div>'+
        '</div>';
    }else{
      resultEl.innerHTML='<div style="color:#ff6b6b;">User not found: '+esc(uid)+'</div>';
    }
  }catch(e){
    if(resultEl) resultEl.innerHTML='<div style="color:#ff6b6b;">Failed</div>';
  }
}
async function resetAllUserData(){ if(!confirm('Confirm? Balance thakbe')) return; try{ var res=await api('admin_reset_all_user_data',{}); if(res&&res.ok) toast('Reset done'); }catch(e){ toast('Failed'); } }
async function saveNotices(){
  const welcome=document.getElementById('adminWelcomeNotice')?.value;
  const earning=document.getElementById('adminEarningPopup')?.value;
  const bonus=document.getElementById('adminBonusText')?.value;
  try{
    const res=await api('admin_save_notices',{welcome_notice:welcome,earning_popup:earning,bonus_text:bonus});
    if(res && res.ok){ 
      toast('Notices saved ✅ - 3 sec pore sobar bot e update hobe'); 
      state.welcome_notice=welcome; 
      state.earning_popup=earning; 
      state.bonus_text=bonus;
      state.rules_update_notice=bonus;
      state.settings = state.settings || {};
      state.settings.welcome_notice=welcome;
      state.settings.earning_popup=earning;
      state.settings.bonus_text=bonus;
      state.settings.rules_update_notice=bonus;
      setTimeout(()=>{
        const rulesEl=document.getElementById('rulesContent');
        if(rulesEl && bonus){ rulesEl.textContent=bonus; }
        toast('Rules updated ✅ Agerta bad gelo, notun ta aslo');
      },3000);
    } else { toast(res?.message||'Failed'); }
  }catch(e){toast('Failed');}
}
window.saveNotices=saveNotices;

function renderHome(){ 
  if(!screen)return; 
  const hist = (state.earnings_history && state.earnings_history.length) ? state.earnings_history : getLast7DaysData();
  const total7 = hist.reduce((a,b)=>a+Number(b.earn||0),0);
  const datesHtml = hist.map(d=>`<span>${esc(d.date)}</span>`).join('');
  const isAdmin = isAdminUser();
  screen.innerHTML=`
  ${heroHomeWithAdmin()}
  <div class="wrap">
    <div style="display:flex;justify-content:center;margin-bottom:12px;">
      <a href="https://t.me/noyonfb1020" target="_blank" class="home-btn btn-botlink" style="width:65%;display:grid;place-items:center;padding:12px;border-radius:12px;font-size:14px;font-weight:900;text-decoration:none;">🆔 Admin ID</a>
    </div>
    <div class="top-link-wrap" style="margin-top:0;">
      <a href="https://t.me/SmartWorkCommunity" target="_blank" class="home-btn btn-official">✨ Official Telegram 🎯</a>
    </div>
    <div class="stats">
      <div class="stat"><div class="label">TODAY'S ADS</div><div class="value" id="homeTodayAds" style="font-size:18px;line-height:1.2;font-weight:800;"><span id="homeAdLijent">${getLijentViews()}/${getLijentMax()} AD</span><br><span id="homeAdPoro" style="font-size:15px;opacity:0.85;">${getPoroViews()}/${getPoroMax()} MG</span></div></div>
      <div class="stat"><div class="label">REFERRALS</div><div class="value" id="homeRef">${userReferrals()}</div></div>
      <div class="stat"><div class="label">TOTAL VIEW</div><div class="value" id="homeTotal">${userTotalViews()}</div></div>
      <div class="stat"><div class="label">EARNED</div><div class="value" id="homeEarned">${money(userEarned())}</div></div>
    </div>
    <div class="chart-card" style="min-height:185px;">
      <div class="chart-title" style="font-size:14px;font-weight:800;">LAST 7 DAYS EARNINGS - Total: ${money(total7)} TK</div>
      <canvas id="earnChart" style="width:100%; height:130px; margin-top:15px;"></canvas>
      <div class="chart-dates" style="font-size:12px;font-weight:700;">${datesHtml}</div>
      <div style="margin-top:10px; font-size:14px; font-weight:800; color:#12c9e7; text-align:center;">Today Total: ${money(hist[hist.length-1]?.earn||0)} TK</div>
    </div>
    ${isAdmin ? `
      <div style="margin:34px 0 120px;display:flex;justify-content:center;">
        <button onclick="openAdminPanel()" aria-label="Open Admin Panel" style="position:relative;overflow:hidden;width:min(88%,340px);min-height:62px;padding:15px 18px;border:1px solid rgba(36,225,255,.72);border-radius:20px;color:#fff;font-size:16px;font-weight:900;letter-spacing:.5px;background:linear-gradient(120deg,#102d4c,#123c5c 48%,#342b70);box-shadow:0 10px 28px rgba(0,0,0,.25),0 0 22px rgba(0,207,255,.26),inset 0 1px 0 rgba(255,255,255,.2);text-shadow:0 1px 8px rgba(25,220,255,.4);cursor:pointer;">⚙️  ADMIN PANEL <span style="display:block;font-size:11px;color:#72eaff;font-weight:700;margin-top:4px;letter-spacing:.8px;">ADMIN ACCESS ONLY</span></button>
      </div>` : ''}
  </div>`;
  setTimeout(()=>{ drawEarnChart(hist); ensureAdminPanel(); }, 150);
}

function showEarningPopupNotice(){
  try{
    const popupText = state.earning_popup || state.settings?.earning_popup || '';
    if(!popupText) return;
    const topNotice=document.getElementById('earningPopupNotice');
    const dot=document.getElementById('earningNoticeDot');
    if(topNotice){
      topNotice.textContent='🔔 Notun Notice Sobai Dekun';
      topNotice.style.display='block';
      topNotice.style.background='linear-gradient(90deg,#ff6b00,#ff9900)';
      topNotice.style.color='#fff';
      topNotice.style.fontWeight='900';
      setTimeout(()=>{ 
        topNotice.style.display='none'; 
        if(dot){
          dot.style.display='grid';
          dot.style.background='#ff0000';
          dot.innerHTML='❗';
        }
      }, 3000);
    }
  }catch(e){}
}
function openEarningPopupFull(){
  try{
    const popupText = state.earning_popup || state.settings?.earning_popup || '';
    if(!popupText){ toast('No notice'); return; }
    const existing = document.getElementById('noticeFullOverlay');
    if(existing) existing.remove();
    const overlay=document.createElement('div'); 
    overlay.id='noticeFullOverlay'; 
    overlay.style.position='fixed'; 
    overlay.style.inset='0'; 
    overlay.style.background='rgba(0,0,0,0.85)'; 
    overlay.style.zIndex='10000'; 
    overlay.style.display='grid'; 
    overlay.style.placeItems='center'; 
    overlay.style.padding='20px'; 
    overlay.onclick=(e)=>{ if(e.target===overlay){ overlay.remove(); } };
    overlay.innerHTML=`<div style="background:#0e1f35;border:1px solid #1d3048;border-radius:16px;padding:20px;max-width:400px;width:90%;max-height:80vh;overflow-y:auto;" onclick="event.stopPropagation()"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;"><h3 style="margin:0;color:#fff;">📢 Sotik Kajer Niyom</h3><button onclick="document.getElementById('noticeFullOverlay')?.remove();" style="background:#0a172b;border:1px solid #2a4a6b;color:#fff;width:28px;height:28px;border-radius:50%;cursor:pointer;">✕</button></div><div style="color:#c8d6e5;line-height:1.7;white-space:pre-wrap;font-size:14px;">${esc(popupText)}</div><button class="gradient-btn" style="width:100%;margin-top:16px;padding:12px;" onclick="document.getElementById('noticeFullOverlay')?.remove();">Bujhechi - Close</button></div>`;
    document.body.appendChild(overlay);
  }catch(e){}
}
window.openEarningPopupFull=openEarningPopupFull;

function updateBalanceUI(){
  try{
    const bal = Number(state.balance||state.user?.balance||0).toFixed(2);
    const el1 = document.getElementById('mainBalance');
    const el2 = document.getElementById('headerBalance');
    const el3 = document.getElementById('profileBalance');
    if(el1) el1.textContent=bal+' TK';
    if(el2) el2.textContent=bal+' TK';
    if(el3) el3.textContent=bal+' TK';
    const topBal = document.querySelector('.balance-amount');
    if(topBal) topBal.textContent='Balance: '+bal+' TK';
    const mainBal = document.querySelector('.main-balance');
    if(mainBal) mainBal.textContent=bal+' TK';
    const fakeEl = document.getElementById('fakeCount');
    const goodEl = document.getElementById('goodCount');
    if(fakeEl) fakeEl.textContent=String(state.user?.fake_count||state.fake_count||0);
    if(goodEl) goodEl.textContent=String(state.user?.good_count||state.good_count||0);
  }catch(e){}
}

async function loadBonusTasks(){
  try{
    const res=await api('get_bonus_tasks');
    if(res&&res.ok){
      window.__bonusTasks=Array.isArray(res.tasks)?res.tasks:[];
      renderBonusTasks(window.__bonusTasks);
      return;
    }
    renderBonusTasks([]);
  }catch(e){
    const container=document.getElementById('bonusTasksList');
    if(container) container.innerHTML='<div style="text-align:center;padding:24px;color:#ff6b6b;">Failed to load tasks</div>';
  }
}

function bonusTaskMeta(t){
  const title=String(t?.title||'').toLowerCase();
  if(title.includes('telegram')) return {bg:'#229ED9',icon:'<svg viewBox="0 0 24 24" width="23" height="23" aria-hidden="true"><path fill="#fff" d="M21.6 4.2 18.3 19c-.25 1.04-.85 1.3-1.72.81l-4.72-3.48-2.28 2.2c-.25.25-.46.46-.94.46l.34-4.81 8.76-7.91c.38-.34-.08-.53-.59-.19L6.33 12.84l-4.64-1.45c-1.01-.32-1.03-1.01.21-1.49L20.04 3.1c.86-.32 1.61.19 1.56 1.1Z"/></svg>'};
  if(title.includes('facebook')||title.includes('fb')) return {bg:'#1877F2',icon:'<svg viewBox="0 0 24 24" width="23" height="23" aria-hidden="true"><path fill="#fff" d="M13.7 21v-7h2.35l.35-2.73H13.7V9.53c0-.79.22-1.33 1.35-1.33h1.44V5.76c-.25-.03-1.1-.11-2.1-.11-2.08 0-3.5 1.27-3.5 3.61v2.01H8.54V14h2.35v7h2.81Z"/></svg>'};
  if(title.includes('youtube')||title.includes('yt')) return {bg:'#ff0000',icon:'<svg viewBox="0 0 24 24" width="23" height="23" aria-hidden="true"><path fill="#fff" d="M21.6 7.2a2.8 2.8 0 0 0-1.97-1.98C17.9 4.75 12 4.75 12 4.75s-5.9 0-7.63.47A2.8 2.8 0 0 0 2.4 7.2C1.93 8.93 1.93 12 1.93 12s0 3.07.47 4.8a2.8 2.8 0 0 0 1.97 1.98c1.73.47 7.63.47 7.63.47s5.9 0 7.63-.47a2.8 2.8 0 0 0 1.97-1.98c.47-1.73.47-4.8.47-4.8s0-3.07-.47-4.8ZM10.1 15.2V8.8l5.4 3.2-5.4 3.2Z"/></svg>'};
  return {bg:'#ff0000',icon:'▶'};
}
function bonusTaskStartKey(taskId){return 'mm_bonus_task_start_'+String(taskId);}
function bonusTaskPendingKey(taskId){return 'mm_bonus_task_pending_'+String(taskId);}

async function startBonusTask(taskId){
  const res=await api('start_bonus_task',{task_id:taskId});
  if(!res||!res.ok) throw new Error(res?.message||'Task start failed');
  localStorage.setItem(bonusTaskStartKey(taskId),String(Number(res.started_at||0)*1000));
  return res;
}

async function completeBonusTask(taskId){
  const res=await api('claim_bonus_task',{task_id:taskId});
  if(res&&res.ok){
    localStorage.removeItem(bonusTaskStartKey(taskId));
    localStorage.removeItem(bonusTaskPendingKey(taskId));
    if(state.user) state.user.balance=res.balance;
    state.balance=res.balance;
    updateBalanceUI();
    toast(`+${res.reward} TK Bonus!`);
    await loadBonusTasks();
    return true;
  }
  toast(res?.message||'Failed');
  return false;
}

async function finishSubscribeBonusTask(taskId){
  const btn=document.querySelector(`[data-bonus-task-id="${CSS.escape(String(taskId))}"]`);
  if(!btn) return;
  btn.disabled=true;
  const total=5;
  let left=total;
  btn.textContent=`Wait ${left}s...`;
  const timer=setInterval(async()=>{
    left--;
    if(left>0){btn.textContent=`Wait ${left}s...`;return;}
    clearInterval(timer);
    btn.textContent='Claiming...';
    await completeBonusTask(taskId);
  },1000);
}

async function claimBonusTask(taskId,url,taskType,requiredTime){
  try{
    const type=String(taskType||'subscribe');
    const required=Math.min(3600,Math.max(0.15,Number(requiredTime||5)));
    if(type==='video'){
      await startBonusTask(taskId);
      localStorage.setItem(bonusTaskStartKey(taskId),String(Date.now()));
    }else{
      localStorage.setItem(bonusTaskPendingKey(taskId),String(Date.now()));
    }
    if(url&&url!=='#'){
      if(window.Telegram?.WebApp?.openLink) window.Telegram.WebApp.openLink(url); else window.open(url,'_blank');
    }
    if(type==='video') toast(`Video timer started: ${required}s`); else toast('Task opened. ফিরে এলে 5s countdown শুরু হবে');
  }catch(e){toast('Failed: '+(e?.message||''));}
}

async function resumeBonusTasks(){
  const tasks=window.__bonusTasks||[];
  for(const task of tasks){
    if(task.claimed) continue;
    const id=String(task.id||'');
    if(!id) continue;
    const type=String(task.task_type||'subscribe');
    if(type==='video'){
      const start=Number(localStorage.getItem(bonusTaskStartKey(id))||0);
      if(!start) continue;
      const required=Math.min(3600,Math.max(0.15,Number(task.required_watch_time||5)));
      const elapsed=(Date.now()-start)/1000;
      if(elapsed>=required){
        const btn=document.querySelector(`[data-bonus-task-id="${CSS.escape(id)}"]`);
        if(btn){btn.textContent='Claiming...';btn.disabled=true;}
        await completeBonusTask(id);
      }else{
        localStorage.removeItem(bonusTaskStartKey(id));
        alert('আপনি সম্পূর্ণ ভিডিও দেখেন নি');
        const btn=document.querySelector(`[data-bonus-task-id="${CSS.escape(id)}"]`);
        if(btn){btn.textContent='Claim';btn.disabled=false;}
      }
    }else if(localStorage.getItem(bonusTaskPendingKey(id))){
      localStorage.removeItem(bonusTaskPendingKey(id));
      await startBonusTask(id);
      finishSubscribeBonusTask(id);
    }
  }
}

function renderBonusTasks(tasks){
  const container=document.getElementById('bonusTasksList');
  if(!container) return;
  if(!Array.isArray(tasks)||tasks.length===0){
    container.innerHTML='<div style="text-align:center;padding:24px;color:#7c8da8;">No bonus tasks yet</div>';
    return;
  }
  container.innerHTML=tasks.map(t=>{
    const id=esc(String(t.id||''));
    const title=esc(t.title||'Bonus Task');
    const reward=money(t.reward||0.5);
    const url=esc(t.url||'#');
    const claimed=!!t.claimed;
    const type=String(t.task_type||'subscribe');
    const required=Math.min(3600,Math.max(0.15,Number(t.required_watch_time||5)));
    const meta=bonusTaskMeta(t);
    const btnText=claimed?'Done':'Claim';
    return `<div style="padding:14px 14px;display:flex;align-items:center;gap:12px;background:#111f34;border:1px solid #1d3048;border-radius:16px;">
      <div style="width:46px;height:46px;background:${meta.bg};border-radius:12px;display:grid;place-items:center;flex-shrink:0;">${meta.icon}</div>
      <div style="flex:1;min-width:0;">
        <div style="font-weight:800;color:#fff;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">♻️ ${title} 🎯</div>
        <div style="font-size:13px;color:#8aa0bb;margin-top:3px;">+${reward} TK</div>
      </div>
      <button data-bonus-task-id="${id}" ${claimed?'disabled':''} onclick="${claimed?'':`claimBonusTask('${id}','${url}','${type}',${required})`}" style="padding:7px 14px;border-radius:8px;border:0;font-weight:800;font-size:13px;cursor:${claimed?'default':'pointer'};min-width:64px;${claimed?'background:#1e2a2a;color:#7c8da8;border:1px solid #2a3a3a;':'background:#ffffff;color:#000;'}">${btnText}</button>
    </div>`;
  }).join('');
  setTimeout(()=>{resumeBonusTasks().catch(()=>{});},50);
}

if(!window.__bonusTaskVisibilityBound){
  window.__bonusTaskVisibilityBound=true;
  document.addEventListener('visibilitychange',()=>{if(!document.hidden) resumeBonusTasks().catch(()=>{});});
}

async function loadAdminBonusTasks(){

  try{
    const res = await api('admin_bonus_get');
    const listEl = document.getElementById('adminBonusList');
    if(!listEl) return;
    if(!res || !res.ok){
      listEl.innerHTML = '<div style="color:#ff6b6b;padding:10px;">Load failed: '+(res?.message||'')+'</div>';
      return;
    }
    if(!res.tasks || res.tasks.length===0){
      listEl.innerHTML = '<div style="color:#7c8da8;padding:10px;">No tasks yet - Add korun</div>';
      return;
    }
    listEl.innerHTML = res.tasks.map(t=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:10px;background:#0a172b;border:1px solid #1d3048;border-radius:8px;margin-bottom:8px;">
      <div style="flex:1;min-width:0;"><div style="font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(t.title)}</div><div style="font-size:11px;color:#7c8da8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(t.url)} - ${t.reward} TK - ${String(t.task_type||'subscribe')==='video'?'Video Watch Type':'Subscribe/Join Type'} - ${Number(t.required_watch_time||5)}s</div></div>
      <button onclick="deleteAdminBonusTask('${t.id}')" style="padding:6px 10px;background:#ff3b30;color:#fff;border:0;border-radius:6px;margin-left:8px;flex-shrink:0;">Delete</button>
    </div>`).join('');
  }catch(e){
    const listEl = document.getElementById('adminBonusList');
    if(listEl) listEl.innerHTML = '<div style="color:#ff6b6b;padding:10px;">Error: '+esc(e?.message||'')+'</div>';
  }
}

async function addAdminBonusTask(){
  const titleEl=document.getElementById('adminBonusTitle');
  const urlEl=document.getElementById('adminBonusUrl');
  const rewardEl=document.getElementById('adminBonusReward');
  const typeEl=document.getElementById('adminBonusType');
  const watchEl=document.getElementById('adminBonusWatchTime');
  const title=titleEl?.value.trim()||'';
  const url=urlEl?.value.trim()||'';
  const reward=parseFloat(rewardEl?.value||'0.5');
  const task_type=(typeEl?.value==='video'?'video':'subscribe');
  let required_watch_time=parseFloat(watchEl?.value||'5');
  if(!Number.isFinite(required_watch_time) || required_watch_time<0.15) required_watch_time=5;
  if(required_watch_time>3600) required_watch_time=3600;
  if(!url){ toast('URL lagbe'); return; }
  const btn = document.querySelector('button[onclick="addAdminBonusTask()"]');
  if(btn){ btn.textContent='Adding...'; btn.disabled=true; }
  try{
    const res=await api('admin_bonus_add',{title: title||'Bonus Task', url, reward, task_type, required_watch_time});
    if(res && res.ok){
      toast('Task added ✅ - '+ (res.task?.title||''));
      if(titleEl) titleEl.value=''; 
      if(urlEl) urlEl.value=''; 
      if(rewardEl) rewardEl.value='0.5';
      if(typeEl) typeEl.value='subscribe';
      if(watchEl) watchEl.value='5';
      await loadAdminBonusTasks();
      await loadBonusTasks();
    } else { 
      toast('Failed: '+(res?.message||'Server error')); 
    }
  }catch(e){ toast('Failed: '+ (e?.message||'')); } 
  finally { if(btn){ btn.textContent='➕ Add Task'; btn.disabled=false; } }
}

async function deleteAdminBonusTask(id){
  if(!confirm('Delete this task?')) return;
  try{
    const res=await api('admin_bonus_delete',{id});
    if(res && res.ok){ toast('Deleted'); loadAdminBonusTasks(); loadBonusTasks(); }
  }catch(e){}
}
window.deleteAdminBonusTask=deleteAdminBonusTask;
window.addAdminBonusTask=addAdminBonusTask;
window.loadAdminBonusTasks=loadAdminBonusTasks;

function renderTasks(){
 if(!screen)return;
 const poroViews=getPoroViews(); const lijentViews=getLijentViews(); const poroMax=getPoroMax(); const lijentMax=getLijentMax();
 const noticeAddSecondSet=Math.max(1, Number(window._noticeAddSecondSet || state.settings?.notice_add_second_set || 30));
 const noticeEarlySeconds=Math.max(0, noticeAddSecondSet-5);
 screen.innerHTML=`${earnHero()}
 <div class="wrap" style="margin-top:-8px;">
   <div class="vpn-badges-row" style="margin-top:4px;margin-bottom:10px;">
     <div class="vpn-badge left" id="vpnBadgeLeft"><div class="badge-label">VPN / PROXY</div><div class="badge-value" id="vpnLeftValue">Checking...</div></div>
     <div class="vpn-badge right" id="vpnBadgeRight"><div class="badge-label">COUNTRY</div><div class="badge-value" id="vpnRightValue">--</div></div>
   </div>
   <div id="rewardAnimWrap" class="reward-anim-wrap" style="display:none;"><div id="rewardAnimText" class="reward-anim-text"></div></div>
   <div class="card" id="mainBalanceCard" style="padding:12px 16px;margin-top:6px;margin-bottom:12px;min-height:72px;transition:all 0.3s ease"><div id="mainBalanceInner"><div class="section-title" style="margin:0;font-size:12px;">Main Balance</div><div style="font-size:28px;font-weight:900;margin-top:4px;line-height:1.2;" id="mainBalanceBig">${money(userBalance())} TK</div></div></div>
   <div class="section-title" style="margin-top:10px;margin-bottom:8px;">Watch & Earn</div>
   <div class="earn-grid" style="margin-top:0;gap:12px;">
    <button id="poroBtn" class="premium-earn-btn poro"><div class="earn-icon">▶</div><div class="earn-text"><b>Poro Earn</b><small id="poroCount">${poroViews}/${poroMax}</small><small style="font-size:12px;color:#8ec8ff;margin-top:2px;display:block;font-weight:800;">MG</small></div></button>
    <button id="lijentBtn" class="premium-earn-btn lijent"><div class="earn-icon">⚡</div><div class="earn-text"><b>Lijent Earn</b><small id="lijentCount">${lijentViews}/${lijentMax}</small><small style="font-size:12px;color:#ffb86e;margin-top:2px;display:block;font-weight:800;">AD</small></div></button>
   </div>
   <div id="earningPopupNotice" style="display:none;position:fixed;top:12px;left:50%;transform:translateX(-50%);background:linear-gradient(90deg,#ff3c00,#ff8a00);color:#fff;padding:10px 16px;border-radius:20px;font-size:13px;font-weight:800;z-index:999;box-shadow:0 8px 24px rgba(255,60,0,0.4);max-width:90%;text-align:center;cursor:pointer;animation:slideDown 0.5s ease;" onclick="openEarningPopupFull()"></div>
   <div id="earningNoticeDot" style="position:absolute;top:8px;right:12px;width:24px;height:24px;background:#ff3c3c;border-radius:50%;display:none;place-items:center;color:#fff;font-size:12px;font-weight:900;cursor:pointer;animation:pulse 1.5s infinite;z-index:5;border:2px solid #fff;" onclick="openEarningPopupFull()">!</div>
   <div class="section-title" style="margin-top:18px;">Bonus Tasks</div>
   <div id="bonusTasksList" style="display:flex;flex-direction:column;gap:10px;">
     <div style="text-align:center;padding:20px;color:#7c8da8;">Loading tasks...</div>
   </div></div>
  </div>
  <div id="adInstructionOverlay" class="overlay hidden"><div class="overlay-card"><div class="overlay-icon">📢</div><h3>Important Notice</h3><p class="overlay-text">15 second ad dekhe ad er upor click kore<br>ad view korte hobe<br><br><span class="highlight">Ad click korar por theke ${noticeAddSecondSet}s porjonto wait korte hobe!<br>${noticeEarlySeconds}s eo fire asle taka add hobe na!</span></p><div class="overlay-timer" id="overlayTimer">5</div><p class="overlay-sub">Ad click theke ${noticeAddSecondSet}s countdown</p><button class="gradient-btn" id="overlayContinueBtn">Bujhechi, Ad Dekhbo</button></div></div>
  <div id="vpnOverlay" class="overlay hidden"><div class="overlay-card vpn-card"><div class="overlay-icon">🌍</div><h3>Location Problem!</h3><p class="overlay-text" id="vpnText">Apnar location thik nei!<br><br>VPN othoba Proxy use kore<br><span id="vpnRequiredCountry" class="highlight">Bangladesh (BD)</span><br>country connect korun,<br>tar por ad dekhte parben.</p><div class="vpn-info" id="vpnInfo"></div><button class="gradient-btn" id="vpnCloseBtn" style="background:linear-gradient(90deg,#ff4d4d,#ff8a4d);">Thik Ache, Bujhechi</button></div></div>`;
 setupEarnButtons(); 
 setTimeout(()=>{ updateVpnBadges(); 
   const bonusText = state.bonus_text || state.settings?.bonus_text || '';
   if(bonusText){ const el=document.getElementById('bonusTextContent'); if(el) el.textContent=bonusText; }
   showEarningPopupNotice();
   loadBonusTasks();
 },100);
}

async function updateVpnBadges(){
  const leftVal=document.getElementById('vpnLeftValue'); const rightVal=document.getElementById('vpnRightValue');
  if(!leftVal||!rightVal) return;
  const country=await getUserCountry();
  if(!country){ leftVal.textContent='Checking...'; rightVal.textContent='--'; return; }
  leftVal.textContent='Connected OK'; 
  rightVal.textContent=country.code+' - '+country.name.substring(0,10);
}
function renderTop(){ if(!screen)return; const referrers=Array.isArray(state.top_referrers)?state.top_referrers:[]; const earners=Array.isArray(state.top_earners)?state.top_earners:[]; let list=topMode==='referrers'?referrers:earners; screen.innerHTML=`${hero()}<div class="wrap"><div class="tabs"><button class="${topMode==='referrers'?'active':''}" onclick="showTop('referrers')">Top Referrers</button><button class="${topMode==='earners'?'active':''}" onclick="showTop('earners')">Top Earners</button></div>${list.length?list.map((x,i)=>{const rawName=x.name||x.first_name||'User'; const name=String(rawName).replace(/[^\w\s\u0980-\u09FF]/g,'').trim()||'User'; let value=topMode==='referrers'?Number(x.referrals||x.count||0):money(x.earned||x.balance||0)+' TK'; const photo=x.photo_url||''; let currentPhoto = tg?.initDataUnsafe?.user?.photo_url || state.user?.photo_url || '';
      let displayPhoto = photo;
      if(!displayPhoto){
        const entryId = x.id || x.user_id || 0;
        const myId = state.user?.id || userId || 0;
        if(entryId && myId && Number(entryId)===Number(myId) && currentPhoto){
          displayPhoto = currentPhoto;
        }
      }
      let avatarHtml=displayPhoto?`<img src="${esc(displayPhoto)}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" onerror="this.style.display='none'; this.nextElementSibling.style.display='grid';"><div style="display:none;width:100%;height:100%;place-items:center;background:linear-gradient(135deg,#1ec8e8,#7b5cff);color:#fff;font-weight:800;border-radius:50%;">${esc(name.charAt(0).toUpperCase())}</div>`:`<div style="width:100%;height:100%;display:grid;place-items:center;background:linear-gradient(135deg,#1ec8e8,#7b5cff);color:#fff;font-weight:800;border-radius:50%;">${esc(name.charAt(0).toUpperCase())}</div>`; return `<div class="leader" style="display:flex;align-items:center;gap:12px;padding:14px 16px;background:#0e1f35;border:1px solid #1d3048;border-radius:14px;margin-bottom:10px;"><div class="rank" style="color:#1ec8e8;font-weight:800;min-width:36px;">#${i+1}</div><div class="avatar-sm" style="width:42px;height:42px;border-radius:50%;overflow:hidden;flex-shrink:0;border:2px solid #1d3048;">${avatarHtml}</div><div class="leader-name" style="flex:1;font-weight:600;">${esc(name)}</div><div class="count" style="color:#1ec8e8;font-weight:700;">${esc(String(value))}</div></div>`;}).join(''):`<div class="empty" style="text-align:center;padding:40px;color:#7c8da8;">No data yet.</div>`}</div>`; }
function showTop(type){topMode=type;renderTop();} window.showTop=showTop;
function withdrawMethodCode(name){
  const low=String(name||'').toLowerCase().trim();
  if(low==='binance'||low==='bc') return 'bc';
  if(low==='mobile recharge'||low==='recharge'||low==='rc') return 'rc';
  if(low==='bkash'||low==='bkas'||low==='bk') return 'bk';
  if(low==='nagad'||low==='ng'||low==='nk') return 'ng';
  if(low==='rocket'||low==='rk') return 'rk';
  return low;
}
function withdrawMinimumLabel(){
  const code=withdrawMethodCode(selectedMethod);
  if(code==='rc') return money(Number(state.min_recharge ?? 20))+' TK';
  if(code==='bc'){ const usdt=Number(state.min_usdt ?? 1); return money(usdt)+' USDT = '+money(usdt*130)+' TK'; }
  return money(state.min_withdraw)+' TK';
}
function updateWithdrawMinimumUI(){
  const el=document.getElementById('withdrawMinimumText');
  if(el) el.textContent='Minimum: '+withdrawMinimumLabel();
  const amountEl=document.getElementById('amount');
  if(amountEl) amountEl.placeholder=(withdrawMethodCode(selectedMethod)==='bc')?'Amount ($)':'Amount (TK)';
}

function renderProfile(){ if(!screen)return; screen.innerHTML=`${hero()}<div class="wrap"><div class="card"><div class="section-title">Referral</div><div class="reward">Earn 10% bonus.</div><input class="input" value="${esc(state.ref_link||'')}" readonly onclick="this.select()"><button class="gradient-btn" onclick="copyRef()">Copy Link</button></div><div class="card"><div class="section-title">Withdraw Money</div><div id="withdrawMinimumText" class="reward">Minimum: ${withdrawMinimumLabel()}</div><div style="margin-top:16px"><b>Payment Method</b></div><div class="method-grid" style="margin:10px 0 14px">${parsePaymentMethods().map(function(methodName){ var methodCode=String(methodName).toLowerCase().trim(); return `<button class="method ${selectedMethod===methodCode?'selected':''}" data-method="${esc(methodCode)}" onclick="selectMethod(this.dataset.method)">${esc(methodName)}</button>`; }).join('')}</div><input id="account" class="input" placeholder="Wallet number"><input id="amount" class="input" type="number" placeholder="Amount (TK)"><button class="gradient-btn" onclick="withdraw()">Request Withdraw</button></div><div class="card" id="withdrawHistoryCard"><div class="section-title">Withdraw History</div><div id="withdrawHistoryList" style="margin-top:12px;color:#8aa0bb;font-size:14px">Loading...</div></div><div class="card" style="background:linear-gradient(135deg,#1a2a45 0%,#162236 100%);border:1px solid #2a4a6b"><div class="section-title" style="color:#4fc3f7">📜 Rules</div><div id="rulesContent" style="white-space:pre-wrap;line-height:1.7;font-size:14px;color:#c8d6e5;margin-top:10px">${esc(state.rules_update_notice || state.bonus_text || state.settings?.bonus_text || state.settings?.rules_update_notice || `❤️ আসসালামু আলাইকুম ❤️
✅ 💎 ᴍᴏɴᴇʏ ᴍᴀx ʙᴏᴛ 💰
✅ Vpn দিয়ে কাজ করতে হবে 
✅ United States , New Zealand, canada
✅ 10 টা রেফার করতে হবে একবার করলে ওই হবে  withdrawal দিতে পারবেন 
✅ মিনিমাম 10 সর্বোচ্চ 100 টাকা 
✅ বিকাশ, নগত , রিচার্জ, Payeer USD, TRX
✅ withdrawal চার্জ 
❇️ বিকাশ 100 হলে 5 টাকা কম✅
100 কম হলে  কাটবে না ❌ 
 ❇️ নগত   ৫ টাকা কম পাবেন ✅
❇️ Payeer USD 5% কম পাবেন ✅ 
❇️ TRX 5% কম পাবেন ✅
💸 সবাই সঠিক নিয়মে কাজ করবেন ইনশাল্লাহ সব সময় পেমেন্ট পাবেন✅ vpn ছাড়া কাজ করলে পাবেন না ❌`)}</div></div></div>`; setTimeout(loadWithdrawHistory,200); setTimeout(()=>{ const el=document.getElementById('rulesContent'); if(el){ const latest = state.rules_update_notice || state.bonus_text || state.settings?.bonus_text || ''; if(latest) el.textContent=latest; } },3000); }
async function loadWithdrawHistory(){
  const listEl=document.getElementById('withdrawHistoryList'); if(!listEl) return;
  try{
    const res=await api('withdraw_history');
    if(!res.ok||!res.history){listEl.innerHTML='<div style="color:#8aa0bb">No history yet</div>'; return;}
    const h=res.history; if(h.length===0){listEl.innerHTML='<div style="color:#8aa0bb">No withdraw request yet</div>'; return;}
    let html=''; for(const w of h){const status=(w.status||'pending').toLowerCase(); let badgeColor='#f1c40f'; let badgeText='Pending'; if(status==='approved'){badgeColor='#2ecc71'; badgeText='Approved';} else if(status==='rejected'){badgeColor='#e74c3c'; badgeText='Rejected';} let date=''; if(w.created_at){ try{const d=new Date(w.created_at); const dd=String(d.getDate()).padStart(2,'0'); const mm=String(d.getMonth()+1).padStart(2,'0'); const yyyy=d.getFullYear(); date=`${dd}-${mm}-${yyyy}`;}catch(e){date=String(w.created_at||'');} } const amountLabel=String(w.method||'').toLowerCase()==='bc'?`${w.amount} USDT`:`${w.amount} TK`; html+=`<div style="background:#0e1e35;border:1px solid #1e3458;border-radius:12px;padding:12px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center"><div><div style="font-weight:600;color:#fff">${amountLabel} - ${esc(paymentMethodLabelClient(w.method))} - ${esc(w.account||'')}</div><div style="font-size:12px;color:#7a8ca8;margin-top:4px">${esc(date)}</div></div><div style="background:${badgeColor};color:#fff;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700">${badgeText}</div></div>`;} listEl.innerHTML=html;
  }catch(e){listEl.innerHTML='<div style="color:#e74c3c">Failed to load history</div>';}
}
function render(){ if(currentTab==='home')renderHome(); if(currentTab==='tasks')renderTasks(); if(currentTab==='top')renderTop(); if(currentTab==='profile')renderProfile(); }
let welcomeNoticeShown=false;
function showWelcomeNotice(){
  try{
    if(welcomeNoticeShown) return; welcomeNoticeShown=true;
    const noticeEl=document.getElementById('notice');
    if(noticeEl){
      noticeEl.innerHTML=`
      <div style="background:#1e2f4a;border-radius:28px;padding:24px;width:min(94%,400px);max-height:92vh;overflow-y:auto;position:relative;border:1px solid #2a4a6b;box-shadow:0 20px 60px rgba(0,0,0,0.6);">
        <button onclick="closeWelcomeNotice()" style="position:absolute;right:16px;top:12px;background:#0a172b;border:1px solid #2a4a6b;color:#8aa0bb;font-size:18px;width:32px;height:32px;border-radius:50%;cursor:pointer;">✕</button>
        <h2 style="text-align:center;color:#1ec8e8;margin:0 0 18px 0;font-size:28px;font-weight:900;letter-spacing:1px;">Notice</h2>
        <div style="background:#000;border-radius:16px;padding:16px;margin-bottom:14px;border:1px solid #1a2a3a;">
          ${(() => {
            const country = String(window._homeNoticeCountry || 'Australia').trim() || 'Australia';
            const flags = {'Australia':'🇦🇺','Canada':'🇨🇦','Italy':'🇮🇹','Egypt':'🇪🇬','United States':'🇺🇸','USA':'🇺🇸','Bangladesh':'🇧🇩','India':'🇮🇳','New Zealand':'🇳🇿','UK':'🇬🇧','United Kingdom':'🇬🇧','Germany':'🇩🇪','France':'🇫🇷','Spain':'🇪🇸','Portugal':'🇵🇹','Japan':'🇯🇵','South Korea':'🇰🇷','China':'🇨🇳','Russia':'🇷🇺','Turkey':'🇹🇷','Saudi Arabia':'🇸🇦','UAE':'🇦🇪','United Arab Emirates':'🇦🇪'};
            const flag = flags[country] || '🌐';
            const customText = String(window._homeNoticeText || '').trim() || `📢কাজের নিয়ম VPN +proxy দিয়ে এড দেখতে হবে ✅ 1 টা অ্যাড দেখে ১৫ সেকেন্ড পর ক্লিক করতে হবে 2 সেকেন্ড থাকতে হবে ▶️ VPN কান্ট্রি 👉 ${country} 🎯`;
            return `
          <div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:12px;">
            <span style="color:#fff;font-weight:900;font-size:20px;letter-spacing:1px;">TIME ZONE</span>
            <span style="font-size:20px;">${flag}</span>
          </div>
          <div style="background:#0a0a0a;border-radius:10px;padding:10px 14px;">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #1a1a1a;">
              <div><div style="color:#aaa;font-size:12px;">${esc(country)}</div><div style="color:#666;font-size:10px;">VPN COUNTRY</div></div><span style="color:#ff2d2d;font-size:18px;">↗️</span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;">
              <div><div style="color:#aaa;font-size:12px;">${esc(country)}</div><div style="color:#666;font-size:10px;">PROXY SERVER</div></div><span style="color:#ff2d2d;font-size:18px;">↗️</span>
            </div>
          </div>
          <div style="display:flex;align-items:center;justify-content:center;gap:8px;margin:14px 0 10px 0;">
            <span style="color:#fff;font-weight:900;font-size:16px;">PROXY 🌐 VPN COUNTRY</span><span>${flag}</span>
          </div>
          <div style="background:#fff;border-radius:10px;padding:8px;">
            <div style="display:flex;align-items:center;justify-content:space-between;padding:7px 10px;border-bottom:1px solid #eee;"><div style="display:flex;align-items:center;gap:8px;"><span style="width:22px;height:22px;background:#012169;border-radius:50%;display:grid;place-items:center;font-size:12px;">${flag}</span><span style="color:#000;font-size:13px;font-weight:600;">${esc(country)} 1</span></div><div style="display:flex;align-items:center;gap:6px;"><span style="color:#666;font-size:11px;">336ms</span><span style="color:#00c853;">▲</span></div></div>
            <div style="display:flex;align-items:center;justify-content:space-between;padding:7px 10px;border-bottom:1px solid #eee;"><div style="display:flex;align-items:center;gap:8px;"><span style="width:22px;height:22px;background:#012169;border-radius:50%;display:grid;place-items:center;font-size:12px;">${flag}</span><span style="color:#000;font-size:13px;font-weight:600;">${esc(country)} 2</span></div><div style="display:flex;align-items:center;gap:6px;"><span style="color:#666;font-size:11px;">325ms</span><span style="color:#00c853;">▲</span></div></div>
            <div style="display:flex;align-items:center;justify-content:space-between;padding:7px 10px;"><div style="display:flex;align-items:center;gap:8px;"><span style="width:22px;height:22px;background:#012169;border-radius:50%;display:grid;place-items:center;font-size:12px;">${flag}</span><span style="color:#000;font-size:13px;font-weight:600;">${esc(country)} 3</span></div><div style="display:flex;align-items:center;gap:6px;"><span style="color:#666;font-size:11px;">234ms</span><span style="color:#00c853;">▲</span></div></div>
          </div>
          <div style="background:#0f223a;border-radius:12px;padding:14px;margin-top:14px;border:1px solid #1e3a5a;">
            <p style="font-size:14px;line-height:1.7;color:#e0f0ff;margin:0;white-space:pre-wrap;">${esc(customText)}</p>
          </div>`;
          })()}
          <button onclick="triggerAdFromNotice()" style="width:100%;margin-top:12px;padding:12px;background:linear-gradient(90deg,#1ec8e8,#7b5cff);border:0;border-radius:10px;color:#fff;font-weight:800;font-size:14px;cursor:pointer;">অ্যাড দেখতে ক্লিক করুন 🔰 - Click Here</button>
        </div>
        <button onclick="closeWelcomeNotice()" style="width:100%;padding:15px;border-radius:14px;border:0;background:linear-gradient(90deg,#7b5cff,#1ec8e8);color:#fff;font-weight:800;font-size:16px;cursor:pointer;">Close</button>
      </div>`;
      noticeEl.style.display='grid'; noticeEl.style.placeItems='center';
    }
  }catch(e){}
}
function closeWelcomeNotice(){ const noticeEl=document.getElementById('notice'); if(noticeEl) noticeEl.style.display='none'; }
window.closeWelcomeNotice=closeWelcomeNotice;
async function triggerAdFromNotice(){ try{ closeWelcomeNotice(); go('tasks'); }catch(e){ closeWelcomeNotice(); } }
window.triggerAdFromNotice=triggerAdFromNotice;
async function load(){ 
  const loadStart=Date.now();
  if(screen){screen.innerHTML=`<div style="min-height:70vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;"><div style="width:48px;height:48px;border:4px solid #1d3048;border-top-color:#12c9e7;border-radius:50%;animation:spin 1s linear infinite;"></div><b>Loading User...</b><style>@keyframes spin{to{transform:rotate(360deg)}}</style></div>`;} 
  const x=await api('bootstrap'); 
  const elapsed=Date.now()-loadStart; if(elapsed<3000){await new Promise(r=>setTimeout(r,3000-elapsed));}
  if(!x||!x.ok){ 
    if(x && x.banned){
      if(screen){screen.innerHTML=`<div style="min-height:70vh;display:flex;align-items:center;justify-content:center;padding:24px;text-align:center;"><div class="card" style="width:100%;max-width:420px;background:#2a1a1a;border-color:#ff4d4d;"><div style="font-size:48px;margin-bottom:12px;">🚫</div><div style="font-size:22px;font-weight:900;margin-bottom:10px;color:#ff6b6b;">Apni ban khaisen!</div><div class="reward" style="color:#ffaaaa;font-size:15px;line-height:1.6;">Apni bot chalate parben na.<br>Admin er sathe contact korun<br><br><a href="https://t.me/noyonfb1020" style="color:#ff6b6b;text-decoration:underline;">@noyonfb1020</a></div></div></div>`;}
      return;
    }
    if(screen){screen.innerHTML=`<div style="min-height:70vh;display:flex;align-items:center;justify-content:center;padding:24px;text-align:center;"><div class="card" style="width:100%;max-width:420px;"><div style="font-size:20px;font-weight:900;margin-bottom:10px;">App Connection Error</div><div class="reward">${esc(x?.message||'Open from Telegram')}</div><button class="gradient-btn" style="margin-top:16px" onclick="load()">Retry</button></div></div>`;}return;} 
  state={...state,...x}; if(x.user)state.user={...state.user,...x.user}; if(x.allowed_countries&&Array.isArray(x.allowed_countries)) state.allowed_countries=x.allowed_countries; if(x.ad_networks) state.ad_networks=x.ad_networks; window._homeNoticeCountry=String(x.settings?.home_notice_country || window._homeNoticeCountry || 'Australia'); window._homeNoticeText=String(x.settings?.home_notice_text || window._homeNoticeText || ''); render(); if(currentTab==="home"){renderHome(); showWelcomeNotice();} startUserBalanceSync(); getUserCountry().then(()=>{if(currentTab==='tasks') updateVpnBadges();});
}
function go(tab){ currentTab=tab; document.querySelectorAll('.bottom-nav button').forEach(button=>{button.classList.toggle('active',button.dataset.tab===tab);}); if(tab==='home'){render(); showWelcomeNotice();}else{render();} if(tg?.HapticFeedback)tg.HapticFeedback.impactOccurred('light'); }
document.querySelectorAll('.bottom-nav button').forEach(button=>{button.addEventListener('click',()=>go(button.dataset.tab));});
function updateBalanceDisplay(balance){ if(balance===undefined||balance===null||balance==='')return; const numericBalance=Number(balance); if(!Number.isFinite(numericBalance))return; state.balance=numericBalance; if(!state.user)state.user={}; state.user.balance=numericBalance; const balanceText=document.getElementById('balanceText'); if(balanceText)balanceText.textContent=`${money(numericBalance)} TK`; const big=document.getElementById('mainBalanceBig'); if(big){big.textContent=`${money(numericBalance)} TK`; big.classList.add('balance-pop'); setTimeout(()=>big.classList.remove('balance-pop'),600);} const homeEarned=document.getElementById('homeEarned'); if(homeEarned) homeEarned.textContent=`${money(state.user.earned||0)}`; }
function updateHomeEarningsInstant(){
  if(!state.user)return;
  const homeEarned=document.getElementById('homeEarned'); if(homeEarned) homeEarned.textContent=money(state.user.earned||0);
  const homeTotal=document.getElementById('homeTotal'); if(homeTotal) homeTotal.textContent=String(userTotalViews());
  const hist=(state.earnings_history&&state.earnings_history.length)?state.earnings_history:getLast7DaysData();
  const total7=hist.reduce((a,b)=>a+Number(b.earn||0),0);
  const title=document.querySelector('.chart-title'); if(title) title.textContent=`LAST 7 DAYS EARNINGS - Total: ${money(total7)} TK`;
  const chartToday=hist[hist.length-1]?.earn||0;
  const chartTodayEl=document.querySelector('.chart-card > div:last-child'); if(chartTodayEl) chartTodayEl.textContent=`Today Total: ${money(chartToday)} TK`;
  const canvas=document.getElementById('earnChart'); if(canvas) drawEarnChart(hist);
}
let _adminBalanceSyncTimer=null;
async function syncUserBalanceNow(){
  if(!userId || document.visibilityState === 'hidden') return;
  try{
    const res=await api('get_user_balance');
    if(res && res.ok){
      const nextBalance=Number(res.balance);
      if(Number.isFinite(nextBalance) && (nextBalance !== Number(state.user?.balance ?? 0) || nextBalance !== Number(state.balance ?? 0))) updateBalanceDisplay(nextBalance);
      if(state.user){
        if(res.earned !== undefined) state.user.earned=Number(res.earned||0);
        if(res.daily_total_views !== undefined){ state.user.daily_total_views=Number(res.daily_total_views||0); state.user.total_views=state.user.daily_total_views; }
        if(res.good_count !== undefined) state.user.good_count=Number(res.good_count||0);
        if(res.fake_count !== undefined) state.user.fake_count=Number(res.fake_count||0);
        if(Array.isArray(res.daily_earnings)) state.earnings_history=res.daily_earnings;
      }
      updateHomeEarningsInstant();
    }
  }catch(e){}
}
function startUserBalanceSync(){
  if(_adminBalanceSyncTimer) clearInterval(_adminBalanceSyncTimer);
  _adminBalanceSyncTimer=setInterval(syncUserBalanceNow,1000);
}
async function rewardFromBot(task){ if(!userId)throw new Error('Telegram user ID is unavailable'); if(!['poro','lijent'].includes(task))throw new Error('Invalid task'); const reward=await api('reward',{task:task}); if(!reward||!reward.ok)throw new Error(reward?.message||'Reward failed'); const newBalance=reward?.balance??reward?.new_balance??reward?.user?.balance??reward?.data?.balance; if(newBalance!==undefined)updateBalanceDisplay(newBalance); if(reward.good_count!==undefined){ if(state.user) state.user.good_count=reward.good_count; const local=getLocalCounts(); saveLocalCounts(local.fake,reward.good_count); updateBoxUI(); } if(state.user){ if(reward.daily_total_views!==undefined) state.user.daily_total_views=Number(reward.daily_total_views||0); else state.user.daily_total_views=Number(state.user.daily_total_views ?? state.user.total_views ?? 0)+1; state.user.total_views=state.user.daily_total_views; } if(reward.daily_earnings) state.earnings_history=reward.daily_earnings; if(reward.earned!==undefined && state.user) state.user.earned=Number(reward.earned||0); updateHomeEarningsInstant(); return reward; }
function showAdInstructionOverlay(){ return new Promise((resolve,reject)=>{ const overlay=document.getElementById('adInstructionOverlay'); const timerEl=document.getElementById('overlayTimer'); const btn=document.getElementById('overlayContinueBtn'); if(!overlay){resolve();return;} overlay.classList.remove('hidden'); overlay.style.display='grid'; let count=5; timerEl.textContent=count; let clicked=false; const interval=setInterval(()=>{count--; if(count>=0) timerEl.textContent=count; if(count<=0){clearInterval(interval); if(!clicked){overlay.style.display='none'; overlay.classList.add('hidden'); reject('timeout');}}},1000); btn.onclick=()=>{clicked=true; clearInterval(interval); overlay.style.display='none'; overlay.classList.add('hidden'); resolve();}; }); }
function showVpnWarning(userCountry){ return new Promise((resolve)=>{ const overlay=document.getElementById('vpnOverlay'); const info=document.getElementById('vpnInfo'); const btn=document.getElementById('vpnCloseBtn'); const reqCountryEl=document.getElementById('vpnRequiredCountry'); if(!overlay){resolve();return;} const allowed=state.allowed_countries.join(', ')||'BD'; const allowedName=state.allowed_country_names||'Bangladesh (BD)'; reqCountryEl.textContent=allowedName+' ('+allowed+')'; if(userCountry){info.innerHTML=`Apnar Current: <b>${esc(userCountry.name)} (${esc(userCountry.code)})</b><br>IP: ${esc(userCountry.ip||'')}`;}else{info.innerHTML=`Location detect hoy ni.`;} overlay.classList.remove('hidden'); overlay.style.display='grid'; btn.onclick=()=>{overlay.style.display='none'; overlay.classList.add('hidden'); resolve();}; playWarningSound(); }); }
async function logFakeAttempt(){ try{incLocalFake(); await api('fake_log',{});}catch(e){} }
function setMainBalanceState(type,data={}){
  const card=document.getElementById('mainBalanceCard'); const inner=document.getElementById('mainBalanceInner'); if(!card||!inner) return;
  if(type==='normal'){ const bal=data.balance!==undefined?data.balance:userBalance(); inner.innerHTML=`<div class="section-title" style="margin:0;font-size:12px;">Main Balance</div><div style="font-size:28px;font-weight:900;margin-top:4px;line-height:1.2;" id="mainBalanceBig">${money(bal)} TK</div>`; card.style.background=''; card.style.border=''; }
  else if(type==='loading'){ inner.innerHTML=`<div style="display:flex;align-items:center;gap:12px;padding:4px 0"><div style="width:38px;height:38px;border-radius:50%;background:#0a1629;display:grid;place-items:center;border:1px solid #1e3458;flex-shrink:0"><span style="font-size:18px">👁️</span></div><div><div style="font-size:10px;letter-spacing:1px;color:#7a8ca8;font-weight:700">MANUAL</div><div style="font-size:15px;font-weight:800;color:#fff;margin-top:1px">Loading Ad...</div></div></div>`; }
  else if(type==='served'){ inner.innerHTML=`<div style="display:flex;align-items:center;gap:12px;padding:4px 0"><div style="width:38px;height:38px;border-radius:50%;background:#2ecc71;display:grid;place-items:center;flex-shrink:0;"><span style="font-size:18px;color:#fff">✓</span></div><div style="flex:1"><div style="font-size:10px;letter-spacing:1px;color:#7a8ca8;font-weight:700">COMPLETED</div><div style="font-size:15px;font-weight:800;color:#fff;margin-top:1px">Ad Served</div></div></div>`; }
  else if(type==='added'){ const amt=data.amount||7; inner.innerHTML=`<div style="text-align:center;padding:2px 0"><div style="font-size:26px;font-weight:900;color:#2ecc71;line-height:1">+${amt} TK</div><div style="font-size:12px;font-weight:700;color:#2ecc71;margin-top:3px">Balance Added!</div><div style="font-size:11px;color:#8ec8a8;margin-top:4px;font-weight:600">Apnar Balance Add Hoyese ✅</div></div>`; }
  else if(type==='warning'){ inner.innerHTML=`<div style="text-align:center;padding:2px 0"><div style="font-size:13px;font-weight:800;color:#f1c40f">⚠️ ${data.msg||'Sabdhan!'}</div><div style="font-size:11px;color:#c8b86e;margin-top:3px">${data.sub||''}</div></div>`; }
}
function getAdNetworkConfig(task){
  const key = task==='poro' ? 'monetag' : 'adspark';
  const cfg = state.ad_networks?.[key] || {};
  return {key, enabled: cfg.enabled === true && String(cfg.code||'').trim() !== '', code: String(cfg.code||'').trim()};
}
function extractScriptInfo(code, task){
  const srcMatch = code.match(/(?:src|data-src)\s*=\s*["']([^"']+)["']/i);
  let src = srcMatch ? srcMatch[1] : '';
  if(!src && /^https?:\/\//i.test(code.trim())) src = code.trim();
  if(!src && /^\/\//.test(code.trim())) src = 'https:' + code.trim();
  if(src && src.startsWith('//')) src = 'https:' + src;
  const sdkMatch = code.match(/data-sdk\s*=\s*["']([^"']+)["']/i);
  const sdk = sdkMatch ? sdkMatch[1].trim() : (task==='poro' ? 'show_10483352' : 'showAdspark');
  return {src, sdk};
}
function loadScriptOnce(src){
  return new Promise((resolve,reject)=>{
    if(!src){resolve();return;}
    const existing = Array.from(document.scripts).find(x=>x.src===src || x.getAttribute('src')===src || x.getAttribute('data-ad-network-src')===src);
    if(existing && existing.dataset.loaded==='1'){resolve();return;}
    const sc=document.createElement('script'); sc.src=src; sc.async=true; sc.setAttribute('data-ad-network-src',src);
    sc.onload=()=>{sc.dataset.loaded='1';resolve();}; sc.onerror=()=>reject(new Error('Ad network SDK load failed'));
    document.head.appendChild(sc);
  });
}
async function ensureAdNetworkLoaded(task){
  const cfg=getAdNetworkConfig(task);
  if(!cfg.enabled) throw new Error((task==='poro'?'Monetag Poro':'AdSpark Lijent')+' ad off');
  const info=extractScriptInfo(cfg.code,task);
  if(task==='poro'){
    if(typeof window[info.sdk]==='function') return window[info.sdk];
    if(info.src) await loadScriptOnce(info.src);
    if(typeof window[info.sdk]==='function') return window[info.sdk];
    throw new Error('Monetag SDK load hoy nai');
  }
  if(typeof window.showAdspark==='function') return window.showAdspark;
  if(typeof window.showAdsparkPopup==='function') return window.showAdsparkPopup;
  if(info.src) await loadScriptOnce(info.src);
  if(typeof window.showAdspark==='function') return window.showAdspark;
  if(typeof window.showAdsparkPopup==='function') return window.showAdsparkPopup;
  throw new Error('AdSpark SDK load hoy nai');
}

async function watchAd(btnId){
 const btn=document.getElementById(btnId); if(!btn)return; if(btn.disabled)return;
 const originalHTML=btn.innerHTML; btn.disabled=true;
 let isSuccess=false;
 try{
  const taskForButton = btnId==='poroBtn' ? 'poro' : 'lijent';
  const netCfg = getAdNetworkConfig(taskForButton);
  if(!netCfg.enabled){ toast((taskForButton==='poro'?'Monetag Poro':'AdSpark Lijent')+' ad off'); btn.innerHTML=originalHTML; btn.disabled=false; return; }
  const poroMax=getPoroMax(); const lijentMax=getLijentMax();
  if(btnId==='poroBtn'){
    const cur=getPoroViews();
    if(cur>=poroMax){ toast('Apnar limit ses! '+cur+'/'+poroMax+' - 6AM er por abar parben'); btn.innerHTML=originalHTML; btn.disabled=false; return; }
  }
  if(btnId==='lijentBtn'){
    const cur=getLijentViews();
    if(cur>=lijentMax){ toast('Apnar limit ses! '+cur+'/'+lijentMax+' - 6AM er por abar parben'); btn.innerHTML=originalHTML; btn.disabled=false; return; }
  }
  btn.innerHTML='<div class="earn-text"><b>Checking Location...</b></div>';
  const userCountry=await getUserCountry(); const allowedList=state.allowed_countries||['BD'];
  if(userCountry&&allowedList.length>0&&!allowedList.includes(userCountry.code)){ await showVpnWarning(userCountry); btn.innerHTML=originalHTML; btn.disabled=false; await updateVpnBadges(); setMainBalanceState('normal'); return; }
    const goodCount=Number(state.user?.good_count ?? getLocalCounts().good); const nextAdNumber=goodCount+1;
  // Notice is shown every configured number of successful ads.
  // Do not persist a pending notice, otherwise an unfinished notice can incorrectly appear on every later click.
  const noticeAdSet = Math.max(1, Number(window._noticeAdSet || state.settings?.notice_ad_set || 5));
  const isStrictMode=(nextAdNumber%noticeAdSet===0);
  if(isStrictMode){ 
    try{
      await showAdInstructionOverlay();
    }catch(e){
      if(e==='timeout'){
        btn.innerHTML=originalHTML; btn.disabled=false; setMainBalanceState('normal'); return;
      }
    } 
  }
  let task=''; setMainBalanceState('loading'); btn.innerHTML='<div class="earn-text"><b>Opening Ad...</b></div>';
  if(btnId==='poroBtn') task='poro'; else if(btnId==='lijentBtn') task='lijent';
  const sessionStart = await api('ad_start',{task:task});
  if(!sessionStart || !sessionStart.ok){ throw new Error(sessionStart?.message||'Ad session start failed'); }
  const requiredSeconds = Number(sessionStart.required_seconds || (sessionStart.strict ? Number(window._noticeAddSecondSet || state.settings?.notice_add_second_set || 30) : 15));
  const startTime=Date.now();
  if(btnId==='poroBtn'){
    const monetagFn = await ensureAdNetworkLoaded('poro');
    try{ await monetagFn(); }catch(adE){ throw new Error('Network error'); }
  } else if(btnId==='lijentBtn'){
    const lijentFn = await ensureAdNetworkLoaded('lijent');
    try{
      if(lijentFn===window.showAdsparkPopup) await lijentFn({ymid:tg?.initDataUnsafe?.user?.id});
      else await lijentFn();
    }catch(adE){ throw new Error('Network error'); }
  }
  const endTime=Date.now(); const watchedSeconds=(endTime-startTime)/1000;
  if(watchedSeconds<requiredSeconds-0.5){ setMainBalanceState('warning',{msg:sessionStart.strict?`Sabdhan! ${requiredSeconds}s Purno Korun!`:`Sabdhan! 15s Dekhun!`,sub:`Apni ${watchedSeconds.toFixed(1)}s dekhechen`}); playWarningSound(); if(tg?.HapticFeedback)tg.HapticFeedback.notificationOccurred('error'); toast(sessionStart.strict?`${requiredSeconds}s lagbe!`:'15s lagbe!'); await logFakeAttempt(); setTimeout(()=>{setMainBalanceState('normal');},3000); btn.innerHTML=originalHTML; btn.disabled=false; return; }
  btn.innerHTML='<div class="earn-text"><b>Claiming...</b></div>'; setMainBalanceState('served'); await new Promise(r=>setTimeout(r,800));
  const rewardPromise = rewardFromBot(task);
  const timeoutPromise = new Promise((_,reject)=>setTimeout(()=>reject(new Error('Server slow, try again')),10000));
  const reward = await Promise.race([rewardPromise, timeoutPromise]);
  const isPoro = task==='poro';
  let newCount = (isPoro ? getPoroViews() : getLijentViews()) + 1;
  const maxCount = isPoro ? getPoroMax() : getLijentMax();
  if(newCount > maxCount) newCount = maxCount;
  if(isPoro){
    state.user.poro_views = newCount;
    savePoroViews(newCount);
  } else {
    state.user.lijent_views = newCount;
    saveLijentViews(newCount);
  }
  // Server reward already increments good_count and rewardFromBot syncs it.
  // Do not increment again here, otherwise one ad would count twice.
  state.user.today_views = (Number(state.user?.today_views||0))+1;
  const poroEl = document.getElementById('poroCount');
  const lijentEl = document.getElementById('lijentCount');
  const homeL = document.getElementById('homeAdLijent');
  const homeP = document.getElementById('homeAdPoro');
  const homeTotal = document.getElementById('homeTotal');
  if(poroEl) poroEl.textContent = `${getPoroViews()}/${getPoroMax()}`;
  if(lijentEl) lijentEl.textContent = `${getLijentViews()}/${getLijentMax()}`;
  if(homeL) homeL.textContent = `${getLijentViews()}/${getLijentMax()} AD`;
  if(homeP) homeP.textContent = `${getPoroViews()}/${getPoroMax()} MG`;
  if(state.user) state.user.daily_total_views = Number(state.user?.daily_total_views ?? state.user?.total_views ?? 0);
  if(homeTotal) homeTotal.textContent = `${userTotalViews()}`;
  setMainBalanceState('added',{amount:reward.reward||0}); saveDailyEarn(reward.reward||0); playTok(); if(tg?.HapticFeedback)tg.HapticFeedback.notificationOccurred('success'); toast(`+${reward.reward||0} TK added!`);
  const updatedBalance=reward?.balance??reward?.new_balance??reward?.user?.balance??reward?.data?.balance;
  if(updatedBalance!==undefined){ 
    state.balance=updatedBalance; state.user.balance=updatedBalance;
    updateBalanceDisplay(updatedBalance);
  }
  setTimeout(()=>{setMainBalanceState('normal',{balance: state.user.balance});},2000);
  isSuccess=true;
  // rewardFromBot already synced the server good_count to localStorage.
  updateBoxUI();
 }catch(e){ 
  setMainBalanceState('warning',{msg:e?.message||'Ad failed'}); 
  setTimeout(()=>{setMainBalanceState('normal');},2500); 
  toast(e?.message||'Ad failed'); 
  btn.innerHTML=originalHTML;
 }finally{ 
  btn.disabled=false; 
  if(!isSuccess){
    try{ btn.innerHTML=originalHTML; }catch{}
  } else {
    try{
      const isPoroBtn = btnId==='poroBtn';
      const cur = isPoroBtn ? getPoroViews() : getLijentViews();
      const max = isPoroBtn ? getPoroMax() : getLijentMax();
      const icon = isPoroBtn ? '▶' : '⚡';
      const label = isPoroBtn ? 'Poro Earn' : 'Lijent Earn';
      const sub = isPoroBtn ? 'MG' : 'AD';
      btn.innerHTML = `<div class="earn-icon">${icon}</div><div class="earn-text"><b>${label}</b><small id="${isPoroBtn?'poroCount':'lijentCount'}">${cur}/${max}</small><small style="font-size:12px;color:${isPoroBtn?'#8ec8ff':'#ffb86e'};margin-top:2px;display:block;font-weight:800;">${sub}</small></div>`;
    }catch{ btn.innerHTML=originalHTML; }
  }
 }
}

function selectMethod(m){
  if(!m) return;
  var low=String(m).toLowerCase().trim();
  if(low==='bikash'||low==='bkas') low='bkash';
  if(low==='ng') low='nagad';
  selectedMethod=low;
  try{ localStorage.setItem('selected_payment_method', low); }catch(e){}
  var all=document.querySelectorAll('.method');
  for(var i=0;i<all.length;i++){
    var b=all[i];
    var txt=b.textContent.trim().toLowerCase();
    if(txt==='bikash'||txt==='bkas') txt='bkash';
    if(txt==='ng') txt='nagad';
    var isSel=(txt===low)||(txt.indexOf(low)!==-1)||(low.indexOf(txt)!==-1);
    if(isSel){ b.classList.add('selected'); } else { b.classList.remove('selected'); }
  }
  updateWithdrawMinimumUI();
  if(tg&&tg.HapticFeedback) tg.HapticFeedback.selectionChanged();
}
window.selectMethod=selectMethod;
async function withdraw(){ 
  if(!selectedMethod){ try{ var sel=document.querySelector('.method.selected'); if(sel){ selectedMethod=sel.textContent.trim().toLowerCase(); } }catch(e){} try{ var cached=localStorage.getItem('selected_payment_method'); if(cached && !selectedMethod) selectedMethod=cached; }catch(e){} }
  const accountEl=document.getElementById('account'); const amountEl=document.getElementById('amount'); 
  const account=accountEl?.value.trim()||''; const amount=amountEl?.value.trim()||''; 
  if(!selectedMethod){toast('Select a payment method');return;} if(!account){toast('Enter wallet number');return;} if(!amount){toast('Enter amount');return;} 
  const amountNumber=Number(amount);
  const methodCodeForMin = withdrawMethodCode(selectedMethod);
  const minForMethod = methodCodeForMin==='rc' ? Number(state.min_recharge ?? 20) : (methodCodeForMin==='bc' ? Number(state.min_usdt ?? 1) : Number(state.min_withdraw||100));
  const minText = methodCodeForMin==='bc' ? money(minForMethod)+' USDT' : money(minForMethod)+' TK';
  if(amountNumber<minForMethod){toast(`Minimum ${minText}`);return;}
  const methodCode=withdrawMethodCode(selectedMethod);
  const requiredBalance = methodCode==='bc' ? amountNumber*130 : amountNumber;
  if(requiredBalance>userBalance()){toast(methodCode==='bc'?'Insufficient balance. 1 USDT = 130 TK.':'Insufficient balance');return;} 
  const x=await api('withdraw',{method:selectedMethod,account:account,amount:amount}); 
  if(x?.ok){
    const card=document.getElementById('mainBalanceCard'); if(card){setMainBalanceState('withdraw',{amount:amount}); setTimeout(()=>{setMainBalanceState('normal');},3000);}
    toast(x?.message||'Withdrawal requested'); selectedMethod='';
    try{ saveLocalCounts(0,0); }catch(e){}
    if(state.user){ state.user.good_count=0; state.user.fake_count=0; }
    updateBoxUI();
    await load(); setTimeout(()=>{if(typeof loadWithdrawHistory==='function') loadWithdrawHistory();},600);
  } else {toast(x?.message||'Failed');}
}
window.withdraw=withdraw;
async function copyRef(){ const link=state.ref_link||''; if(!link){toast('No link');return;} try{ if(navigator.clipboard)await navigator.clipboard.writeText(link); else{ const input=document.createElement('input'); input.value=link; document.body.appendChild(input); input.select(); document.execCommand('copy'); input.remove(); } toast('Copied'); }catch{toast('Copy failed');} }
window.copyRef=copyRef;
function closeNotice(){ const notice=document.getElementById('notice'); if(notice)notice.style.display='none'; }
function setupEarnButtons(){ const poroBtn=document.getElementById('poroBtn'); const lijentBtn=document.getElementById('lijentBtn'); if(poroBtn&&!poroBtn.dataset.bound){poroBtn.dataset.bound='1'; poroBtn.onclick=()=>watchAd('poroBtn');} if(lijentBtn&&!lijentBtn.dataset.bound){lijentBtn.dataset.bound='1'; lijentBtn.onclick=()=>watchAd('lijentBtn');} }
let earnButtonWatcher=null; if(typeof MutationObserver!=='undefined'&&document.body){ earnButtonWatcher=new MutationObserver(()=>{setupEarnButtons();}); earnButtonWatcher.observe(document.body,{childList:true,subtree:true}); }
setupEarnButtons(); load();