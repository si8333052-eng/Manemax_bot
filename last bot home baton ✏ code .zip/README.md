MONEY MAX BOT V9
- Updated only the 7-day earnings chart display height and bar drawing scale so the chart fills more of the marked area.
- Kept earning/balance/referral logic and other button behavior unchanged.
- Please test the chart on the live Telegram WebApp after uploading.
